package com.hoardersoft.photo;

import java.io.*;

/**
 * Class to rename files in the current directory based on the parent
 * directory. For example, a file called "P1000.jpg" in a directory
 * "sea-world-1003" will get renamed to "../sea-world-1003-P1000.jpg"
 * (assuming "jpg" is passed in as the extension to rename).
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
public class HSRenameAsDirectory {
    private static final String SEPARATOR = "-";

    /**
     * Main method.
     * @param args command line arguments (one argument - file extension to rename)
     */
    public static void main(String[] args) {
        if ((args.length < 1) || args[0].equals("/?")) {
            System.out.println("Usage: java HSRenameAsDirectory <filename extension>");
            System.exit(0);
        }

        String extension = args[0].startsWith(".") ? args[0].toLowerCase() : "." + args[0].toLowerCase();
        String dirString = System.getProperty("user.dir");

        if (dirString == null) {
            System.out.println("Unable to find current directory!");
            System.exit(-1);
        }

        renameDir(new File(dirString), extension);
    }

    /**
     * Renames a directory.
     * @param dir the directory to rename
     * @param extension the extension
     */
    private static void renameDir(File dir, String extension) {
        if (!dir.exists() || !dir.isDirectory()) {
            System.out.println("Directory does not exist or isn't a directory: " + dir);

            return;
        }

        String dirName = dir.getName();
        File[] files   = dir.listFiles();
        File parentDir = dir.getParentFile();

        if (parentDir == null) {
            System.out.println("Directory does not have a parent directory to move files to: " + dir);
        }

        for (int i = 0; i < files.length; i++) {
            File file = files[i];

            if (file.isDirectory()) {
                renameDir(file, extension);
            }
            else if (file.isFile() && file.getName().toLowerCase().endsWith(extension)) {
                String newName = dirName + SEPARATOR + file.getName();

                if (!file.renameTo(new File(parentDir, newName))) {
                    System.out.println("Unable to rename file: \"" + file.getName() + "\"");
                }
                else {
                    System.out.println("Renamed file: \"" + file.getName() + "\"");
                }
            }
        }
    }
}
