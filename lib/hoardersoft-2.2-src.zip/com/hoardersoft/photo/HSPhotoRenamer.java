package com.hoardersoft.photo;

import com.hoardersoft.util.*;
import com.hoardersoft.menu.HSMenu;
import com.hoardersoft.statusbar.HSStatusBar;
import com.hoardersoft.statusbar.HSStatusBarAdapter;

import javax.swing.*;

import java.io.File;
import java.io.FileFilter;
import java.awt.event.*;
import java.awt.*;

import info.clearthought.layout.TableLayout;

/**
 * Handy utility for renaming picture files.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
public class HSPhotoRenamer extends JFrame {
    private static final double SCALE       = 0.5;
    private static final int MINUMUM_SIZE   = 100;
    private static final String[] IMAGES    = new String[]{ ".jpg", ".jpeg", ".gif", ".png" };
    private File m_directory                = null;
    private File m_lastDirectory            = null;
    private File[] m_files                  = null;
    private int m_currentFile               = -1;
    private FileFilter m_fileFilter         = null;
    private JTextField m_nameTextField      = new JTextField();
    private JTextField m_extensionTextField = new JTextField();
    private JLabel m_imageLabel             = new JLabel();
    private final static double BORDER      = 0.0;
    private final static int SPACE          = 5;
    private final static double FILL        = TableLayout.FILL;
    private final static double PREF        = TableLayout.PREFERRED;
    private final static double[][] SIZES   = {
        {
            BORDER, FILL, 40, 24, 24, 24, BORDER
        }, { BORDER, FILL, PREF, BORDER }
    };

    /**
     * Constructor.
     * @param directory the initial directory
     */
    public HSPhotoRenamer(File directory) {
        super("Photo Renamer");

        // Set the icon
        setIconImage(HSIconUtil.loadImage("HoarderSoft.gif").getImage());

        // We want to exit on window close
        HSBeanUtil.addCloseExitListener(this);

        // Set the layout and the status bar
        Container cont        = getContentPane();
        HSStatusBar statusBar = new HSStatusBar();

        cont.setLayout(new BorderLayout());
        cont.add(statusBar, BorderLayout.SOUTH);

        // Set up the menu bar
        JMenuBar menuBar = new JMenuBar();
        HSMenu fileMenu  = new HSMenu("File", statusBar);
        HSMenu helpMenu  = new HSMenu("Help", statusBar);

        fileMenu.add(m_selectDirAction);
        fileMenu.addSeparator();
        fileMenu.add(m_exitAction);
        helpMenu.add(m_aboutAction);
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        // Set up the main panel
        TableLayout tableLayout    = new TableLayout(SIZES);
        JPanel mainPanel           = new JPanel(tableLayout);
        JScrollPane scrollPane     = HSBeanUtil.createScrollPane(m_imageLabel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        JButton previousButton     = new JButton(m_previousAction);
        JButton nextButton         = new JButton(m_nextAction);
        JButton renameButton       = new JButton(m_renameAction);
        HSStatusBarAdapter adapter = new HSStatusBarAdapter(statusBar);

        previousButton.addMouseListener(adapter);
        nextButton.addMouseListener(adapter);
        renameButton.addMouseListener(adapter);
        tableLayout.setHGap(SPACE);
        tableLayout.setVGap(SPACE);
        mainPanel.add(scrollPane, "1,1,5,1");
        mainPanel.add(m_nameTextField, "1,2");
        mainPanel.add(m_extensionTextField, "2,2");
        mainPanel.add(previousButton, "3,2");
        mainPanel.add(nextButton, "4,2");
        mainPanel.add(renameButton, "5,2");
        cont.add(mainPanel, BorderLayout.CENTER);
        m_nameTextField.addActionListener(m_renameAction);
        m_extensionTextField.setEditable(false);

        // On focus gain the name text field should select its text
        m_nameTextField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                m_nameTextField.selectAll();
            }
        });

        // Set up the file filter (files only)
        m_fileFilter = new FileFilter() {
            public boolean accept(File f) {
                return f.isFile();
            }
        };

        // Set the initial size
        setSize(460, 600);

        // Set the initial directory and update the GUI
        setDirectory(directory);
    }

    /**
     * Sets the directory.
     * @param directory the directory (null to clear/reset)
     */
    public void setDirectory(File directory) {
        // First do a reset
        m_directory   = null;
        m_files       = null;
        m_currentFile = -1;

        if ((directory != null) && directory.isDirectory()) {
            m_directory = directory;
            m_files     = m_directory.listFiles(m_fileFilter);

            if (m_files.length > 0) {
                m_currentFile = 0;
            }
            else {
                // No files so just reset
                m_directory = null;
                m_files     = null;
            }
        }

        // Update the "last directory"
        if (m_directory != null) {
            m_lastDirectory = m_directory;
        }

        // Update the GUI
        updateGUI();
    }

    /**
     * Updates the GUI.
     */
    private void updateGUI() {
        boolean hasFile = hasFile();

        m_nameTextField.setEnabled(hasFile);
        m_renameAction.setEnabled(hasFile);
        m_previousAction.setEnabled(hasFile && (m_currentFile > 0));
        m_nextAction.setEnabled(hasFile && (m_currentFile < (m_files.length - 1)));
        m_nameTextField.setText("");
        m_extensionTextField.setText("");
        m_imageLabel.setIcon(null);

        if (hasFile) {
            File currentFile = m_files[m_currentFile];
            String name      = getName(currentFile);
            String extension = getExtension(currentFile);

            m_nameTextField.setText(name);
            m_extensionTextField.setText(extension);

            if (isImage(currentFile)) {
                ImageIcon originalImage = new ImageIcon(currentFile.getAbsolutePath());
                int iconWidth           = originalImage.getIconWidth();
                int iconHeight          = originalImage.getIconHeight();

                if ((iconWidth > 0) && (iconHeight > 0)) {
                    int scaledWidth  = (int) (originalImage.getIconWidth() * SCALE);
                    int scaledHeight = (int) (originalImage.getIconHeight() * SCALE);

                    if ((scaledWidth < MINUMUM_SIZE) || (scaledHeight < MINUMUM_SIZE)) {
                        // No need to scale
                        m_imageLabel.setIcon(originalImage);
                    }
                    else {
                        ImageIcon scaledImage = new ImageIcon(originalImage.getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_FAST));

                        m_imageLabel.setIcon(scaledImage);
                    }
                }
            }
        }

        // By default the textfield has focus and is all selected
        m_nameTextField.selectAll();
        m_nameTextField.requestFocus();
    }

    /**
     * Returns whether a file is a supported image.
     * @param file the file
     * @return whether the file is a supported image
     */
    private boolean isImage(File file) {
        String lowerExtension = getExtension(file).toLowerCase();

        for (int i = 0; i < IMAGES.length; i++) {
            if (IMAGES[i].equals(lowerExtension)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns whether there is a current file.
     * @return whether there is a current file
     */
    private boolean hasFile() {
        return (m_directory != null) && (m_files != null) && (m_currentFile >= 0);
    }

    /**
     * Gets the name of a file (ie the name without the extension).
     * @param file the file
     * @return the name (without the extension, whole filename if no extension)
     */
    private String getName(File file) {
        String name = file.getName();
        int lastDot = name.lastIndexOf(".");

        if (lastDot >= 0) {
            return name.substring(0, lastDot);
        }

        return name;
    }

    /**
     * Gets the extension of a file (ie the extension with preceding dot).
     * @param file the file
     * @return the extension (with preceding dot, blank string if no extension)
     */
    private String getExtension(File file) {
        String name = file.getName();
        int lastDot = name.lastIndexOf(".");

        if (lastDot >= 0) {
            return name.substring(lastDot);
        }

        return "";
    }

    /**
     * Moves to the next file.
     * @param resetIfEnd whether to reset the directory if at the end
     */
    private void moveToNextFile(boolean resetIfEnd) {
        if (hasFile()) {
            if (m_currentFile < (m_files.length - 1)) {
                // Go to next file
                m_currentFile++;

                // Update the GUI
                updateGUI();
            }
            else if (resetIfEnd) {
                // We have got to the end and are resetting
                setDirectory(null);
            }
        }
    }

    /**
     * Moves to the previous file.
     * @param resetIfStart whether to reset the directory if at the start
     */
    private void moveToPreviousFile(boolean resetIfStart) {
        if (hasFile()) {
            if (m_currentFile > 0) {
                // Go to previous file
                m_currentFile--;

                // Update the GUI
                updateGUI();
            }
            else if (resetIfStart) {
                // We have got to the start and are resetting
                setDirectory(null);
            }
        }
    }

    /**
     * Show the dialog.
     */
    public void showDialog() {
        setVisible(true);
        updateGUI();
    }

    /**
     * Called to show the about dialog.
     */
    private void showAboutDialog() {
        HSAboutDialog aboutDialog = new HSAboutDialog(this, "HSPhotoRenamer");

        aboutDialog.showDialog();
    }

    private HSAbstractAction m_selectDirAction = new HSAbstractAction("Select...", "Selects the directory", "Open.png") {
        public void actionPerformed(ActionEvent e) {
            JFileChooser chooser = new JFileChooser(m_lastDirectory);

            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            int option = chooser.showOpenDialog(HSPhotoRenamer.this);

            if (option == JFileChooser.APPROVE_OPTION) {
                setDirectory(chooser.getSelectedFile());
            }
        }
    };
    private HSAbstractAction m_exitAction = new HSAbstractAction("Exit", "Exits the program") {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    };
    private Action m_aboutAction = new HSAbstractAction("About...", "Raises the about dialog") {
        public void actionPerformed(ActionEvent e) {
            showAboutDialog();
        }
    };
    private HSAbstractAction m_renameAction = new HSAbstractAction(null, "Renames the current file", "Rename.png", "Rename File") {
        public void actionPerformed(ActionEvent e) {
            if (hasFile()) {
                String newName     = m_nameTextField.getText().trim();
                File currentFile   = m_files[m_currentFile];
                String oldName     = getName(currentFile);
                String extension   = getExtension(currentFile);
                File parent        = currentFile.getParentFile();
                String oldFilename = oldName + extension;
                String newFilename = newName + extension;

                // We don't rename to an empty name or the same name and we must have a parent
                if ((newName.length() > 0) && !newName.equals(oldName) && (parent != null)) {
                    // Rename the file
                    File renameFile = new File(parent, newFilename);

                    if (!currentFile.renameTo(renameFile)) {
                        // Work out why...
                        if (renameFile.exists()) {
                            // We tried to rename to a file that already exists
                            JOptionPane.showMessageDialog(HSPhotoRenamer.this, "Unable to rename file \"" + oldFilename + "\" to \"" + newFilename + "\"\n(a file with that name already exists)", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        else {
                            // Don't really know why!
                            JOptionPane.showMessageDialog(HSPhotoRenamer.this, "Unable to rename file \"" + oldFilename + "\" to \"" + newFilename + "\"", "Error", JOptionPane.ERROR_MESSAGE);
                        }

                        // Update the GUI
                        updateGUI();
                    }
                    else {
                        // Update our cache
                        m_files[m_currentFile] = renameFile;

                        // Move to next file and reset if at end
                        moveToNextFile(true);
                    }
                }
                else {
                    // Just go to the next file and reset if at end
                    moveToNextFile(true);
                }
            }
        }
    };
    private HSAbstractAction m_nextAction = new HSAbstractAction(null, "Skips to the the next file", "Next.png", "Next File") {
        public void actionPerformed(ActionEvent e) {
            // Move to next file
            moveToNextFile(false);
        }
    };
    private HSAbstractAction m_previousAction = new HSAbstractAction(null, "Skips to the the next file", "Previous.png", "Previous File") {
        public void actionPerformed(ActionEvent e) {
            // Move to previous file
            moveToPreviousFile(false);
        }
    };

    /**
     * Main method.
     * @param args command line arguments (can specify a directory)
     */
    public static void main(String[] args) {
        // Set the look and feel first
        HSBeanUtil.setLookAndFeel();

        // Now grab the first command line argument (if any)
        File dir = null;

        if (args.length > 0) {
            dir = new File(args[0]);

            if (!dir.isDirectory()) {
                dir = null;
            }
        }

        HSPhotoRenamer renamer = new HSPhotoRenamer(dir);

        renamer.showDialog();
    }
}
