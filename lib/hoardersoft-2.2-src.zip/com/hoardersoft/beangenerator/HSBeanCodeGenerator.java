package com.hoardersoft.beangenerator;

import com.hoardersoft.util.HSStringUtil;

import java.util.Iterator;

/**
 * Class responsible for all property code generation.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSBeanCodeGenerator {
    /**
     * Returns the class start code.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the class start code
     */
    public static String getClassStartCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer = new StringBuffer();

        buffer.append("import java.util.*;\n");
        buffer.append("\n");
        buffer.append("public class " + beanClass.getClassName() + (options.isCloneMethod() ? " implements Cloneable" : "") + "\n");
        buffer.append("{\n");

        return buffer.toString();
    }

    /**
     * Returns the class end code.
     *
     * @param beanClass the bean class to return the code for
     * @return the class end code
     */
    public static String getClassEndCode(HSBeanClass beanClass) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer = new StringBuffer();

        buffer.append("}\n");

        return buffer.toString();
    }

    /**
     * Returns the declaration code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the declaration code
     */
    public static String getDeclarationCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();

        buffer.append(indentString1 + "private " + prop.getType() + " " + prop.getVariableName() + ";\n");

        return buffer.toString();
    }

    /**
     * Gets the accessor code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the accessor code
     */
    public static String getAccessorCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer = new StringBuffer();

        if (prop.isReadAllowed()) {
            // Get our read accessors
            if (!prop.isMultiValue()) {
                buffer.append(getNormalGetterCode(prop, options));
            }
            else {
                for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
                    if (E_HSTypes.isReadMultiFlag(i) && prop.getMultiFlag(i) && prop.isMultiValid(i)) {
                        buffer.append(getMultiAccessorCode(prop, i, options));
                    }
                }
            }
        }

        if (prop.isWriteAllowed()) {
            // Get our write accessors
            if (!prop.isMultiValue()) {
                buffer.append(getNormalSetterCode(prop, options));
            }
            else {
                for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
                    if (E_HSTypes.isWriteMultiFlag(i) && prop.getMultiFlag(i) && prop.isMultiValid(i)) {
                        buffer.append(getMultiAccessorCode(prop, i, options));
                    }
                }
            }
        }

        return buffer.toString();
    }

    /**
     * Returns the constructor code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the equals code
     */
    public static String getConstructorCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String className     = beanClass.getClassName();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Class constructor.\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + className + "()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");
        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Class constructor.\n");

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();

            buffer.append(indentString1 + " * @param " + prop.getName() + " " + prop.getDescription() + "\n");
        }

        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + className + "(");

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();

            buffer.append(prop.getType() + " " + prop.getName());

            if (iter.hasNext()) {
                buffer.append(", ");
            }
        }

        buffer.append(")\n");
        buffer.append(indentString1 + "{\n");

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();

            buffer.append(indentString2 + prop.getCodeVariableName() + " = " + prop.getName() + ";\n");
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the equals code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the equals code
     */
    public static String getEqualsCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String className     = beanClass.getClassName();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Compares this object with another (using only relevant data members).\n");
        buffer.append(indentString1 + " * @param rhs the object for the comparison\n");
        buffer.append(indentString1 + " * @return whether the object for comparison is equal to this object\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public boolean equals(Object rhs)\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "boolean same = false;\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "if (rhs instanceof " + className + ")\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + className + " other = (" + className + ") rhs;\n");
        buffer.append(indentString3 + "\n");

        boolean firstSame = true;

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();
            String codeVarName  = prop.getCodeVariableName();
            String varName      = prop.getVariableName();

            if (firstSame) {
                buffer.append(indentString3 + "same = ");
            }
            else {
                buffer.append(indentString3 + "same = same && (");
            }

            if (prop.isNativeType()) {
                // We are native - just use equality (==)
                buffer.append(codeVarName + " == other." + varName);
            }
            else if (prop.isArray()) {
                // We are an array - use the appropriate Arrays method
                buffer.append("Arrays.equals(" + codeVarName + ", other." + varName + ")");
            }
            else {
                // We are just an object (or collection) - just use object equals
                buffer.append(getObjectEqualsCode(codeVarName, "other." + varName, options));
            }

            if (firstSame) {
                buffer.append(";\n");

                firstSame = false;
            }
            else {
                buffer.append(");\n");
            }
        }

        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return same;\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the object equality test code.
     * @param o1 the first object
     * @param o2 the second object
     * @param options the options
     * @return the object equality test code
     */
    private static String getObjectEqualsCode(String o1, String o2, HSBeanOptions options) {
        E_HSObjectEqualityMethod objectEqualityMethod = options.getObjectEqualityMethod();

        if (objectEqualityMethod.equals(E_HSObjectEqualityMethod.STATIC)) {
            return ("equals(" + o1 + ", " + o2 + ")");
        }
        else if (objectEqualityMethod.equals(E_HSObjectEqualityMethod.CLASS)) {
            return (options.getObjectEqualityClass() + ".equals(" + o1 + ", " + o2 + ")");
        }

        // Default to inline
        return ("(" + o1 + " == null) ? (" + o2 + " == null) : " + o1 + ".equals(" + o2 + ")");
    }

    /**
     * Returns the clone code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the clone code
     */
    public static String getCloneCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String className     = beanClass.getClassName();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;
        String indentString4 = indentString3 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets a clone of this object.\n");
        buffer.append(indentString1 + " * @return the clone of this object\n");
        buffer.append(indentString1 + " * @throws CloneNotSupportedException if clone is not supported\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public Object clone() throws CloneNotSupportedException\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + className + " clone = (" + className + ") super.clone();\n");
        buffer.append(indentString2 + "\n");

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();
            String codeVarName  = prop.getCodeVariableName();
            String varName      = prop.getVariableName();
            String type         = prop.getType();
            String multiType    = prop.getMultiType();
            String multiVarName = HSStringUtil.ensureValidVariableName(prop.getMultiType(), "object");

            if (prop.isImmutableType()) {
                // We are immutable - nothing to do (super.clone() copied it fine)
            }
            else if (prop.isArray()) {
                // We are an array - copy the array, cloning each element (if non-null object)
                buffer.append(indentString2 + "if (" + codeVarName + " != null)\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + "clone." + varName + " = new " + multiType + "[" + codeVarName + ".length];\n");
                buffer.append(indentString3 + "\n");
                buffer.append(indentString3 + "for (int i = 0; i < " + codeVarName + ".length; i++)\n");
                buffer.append(indentString3 + "{\n");

                if (prop.isImmutableMultiType()) {
                    // Immutable multi-type - use plain assignment
                    buffer.append(indentString4 + "clone." + varName + "[i] = " + codeVarName + "[i];\n");
                }
                else {
                    // Object multi-type - use cloning (if not null)
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = " + codeVarName + "[i];\n");
                    buffer.append(indentString4 + "\n");
                    buffer.append(indentString4 + "// Note - this code will not compile unless " + prop.getMultiType() + " supports Cloneable\n");

                    if (E_HSTypes.isGenericObject(prop.getMultiType())) {
                        // No cast required
                        buffer.append(indentString4 + "clone." + varName + "[i] = ((" + multiVarName + " == null) ? null : " + multiVarName + ".clone());\n");
                    }
                    else {
                        // Cast to the appropriate multi-value type
                        buffer.append(indentString4 + "clone." + varName + "[i] = (" + multiType + ") ((" + multiVarName + " == null) ? null : " + multiVarName + ".clone());\n");
                    }
                }

                buffer.append(indentString3 + "}\n");
                buffer.append(indentString2 + "}\n");
            }
            else if (prop.isCollection()) {
                // We are a collection - copy the collection, cloning each element if not null (why isn't this the default for clone ?)
                // Note if we are a collection interface then use clone to do a shallow copy and then clear !!
                buffer.append(indentString2 + "if (" + codeVarName + " != null)\n");
                buffer.append(indentString2 + "{\n");

                if (E_HSTypes.isCollectionInterface(type)) {
                    buffer.append(indentString3 + "// Note - this code will not compile unless " + type + " supports Cloneable\n");
                    buffer.append(indentString3 + "clone." + varName + " = (" + type + ") " + codeVarName + ".clone();\n");
                    buffer.append(indentString3 + "clone." + varName + ".clear();\n");
                }
                else {
                    buffer.append(indentString3 + "clone." + varName + " = new " + type + "(" + codeVarName + ".size());\n");
                }

                buffer.append(indentString3 + "\n");
                buffer.append(indentString3 + "for (Iterator iter = " + codeVarName + ".iterator(); iter.hasNext(); )\n");
                buffer.append(indentString3 + "{\n");

                if (E_HSTypes.isGenericObject(prop.getMultiType())) {
                    // No cast required
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = iter.next();\n");
                }
                else {
                    // Cast to the appropriate multi-value type
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = (" + prop.getMultiType() + ") iter.next();\n");
                }

                buffer.append(indentString4 + "\n");

                if (prop.isImmutableMultiType()) {
                    // Immutable so add directly
                    buffer.append(indentString4 + "clone." + varName + ".add(" + multiVarName + ");\n");
                }
                else {
                    // Clone object
                    buffer.append(indentString4 + "// Note - this code will not compile unless " + prop.getMultiType() + " supports Cloneable\n");
                    buffer.append(indentString4 + "clone." + varName + ".add((" + multiVarName + " == null) ? null : (" + multiVarName + ".clone()));\n");
                }

                buffer.append(indentString3 + "}\n");
                buffer.append(indentString2 + "}\n");
            }
            else {
                // We are just an object - use clone (if not null)
                buffer.append(indentString2 + "if (" + codeVarName + " != null)\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + "// Note - this code will not compile unless " + type + " supports Cloneable\n");
                buffer.append(indentString3 + "clone." + varName + " = (" + type + ") " + codeVarName + ".clone();\n");
                buffer.append(indentString2 + "}\n");
            }
        }

        buffer.append(indentString1 + "\n");
        buffer.append(indentString2 + "return clone;\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the hashcode code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the hashcode code
     */
    public static String getHashcodeCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;
        String indentString4 = indentString3 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Returns a hash code for this object (required for hashed storage).\n");
        buffer.append(indentString1 + " * @return a hash code for this object\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public int hashCode()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "int hashCode = 17;\n");
        buffer.append(indentString2 + "\n");

        boolean longTempAdded = false;

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();
            String varName      = prop.getCodeVariableName();
            String type         = prop.getType();
            String multiType    = prop.getMultiType();

            if (prop.isArray()) {
                // Add all the elements to our hashcode
                buffer.append(indentString2 + "if (" + varName + " == null)\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + "hashCode = (37 * hashCode);\n");
                buffer.append(indentString2 + "}\n");
                buffer.append(indentString2 + "else\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + "for (int i = 0; i < " + varName + ".length; i++)\n");
                buffer.append(indentString3 + "{\n");

                if (prop.isNativeMultiType()) {
                    // We have a native type - use some logic
                    longTempAdded = addNativeHashCodeString(buffer, varName + "[i]", multiType, indentString4, longTempAdded);
                }
                else {
                    // We have an object - add the recursive hashcode
                    buffer.append(indentString4 + "hashCode = (37 * hashCode) + (" + varName + "[i] == null ? 0 : " + varName + "[i].hashCode());\n");
                }

                buffer.append(indentString3 + "}\n");
                buffer.append(indentString2 + "}\n");
            }
            else if (prop.isNativeType()) {
                // We have a native type - use some logic
                longTempAdded = addNativeHashCodeString(buffer, varName, type, indentString2, longTempAdded);
            }
            else {
                // We have an object - add the recursive hashcode
                buffer.append(indentString2 + "hashCode = (37 * hashCode) + (" + varName + " == null ? 0 : " + varName + ".hashCode());\n");
            }
        }

        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return hashCode;\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the copy code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the copy code
     */
    public static String getCopyCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String className     = beanClass.getClassName();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;
        String indentString4 = indentString3 + indentString1;

        // First work out if we need to do a clone at any point
        boolean cloneUsed = false;

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();

            if (prop.isImmutableType()) {
                // Clone never used
            }
            else if (prop.isArray()) {
                if (!prop.isImmutableMultiType()) {
                    cloneUsed = true;
                }
            }
            else if (prop.isCollection()) {
                if (!prop.isImmutableMultiType()) {
                    cloneUsed = true;
                }
            }
            else {
                cloneUsed = true;
            }
        }

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Copies another object into this object.\n");
        buffer.append(indentString1 + " * @param other the other object (" + className + ") to copy into this object\n");

        if (cloneUsed) {
            buffer.append(indentString1 + " * @throws CloneNotSupportedException if clone is not supported\n");
            buffer.append(indentString1 + " */\n");
            buffer.append(indentString1 + "public void copy(" + className + " other) throws CloneNotSupportedException\n");
        }
        else {
            buffer.append(indentString1 + " */\n");
            buffer.append(indentString1 + "public void copy(" + className + " other)\n");
        }

        buffer.append(indentString1 + "{\n");

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop = (HSBeanProperty) iter.next();
            String codeVarName  = prop.getCodeVariableName();
            String varName      = prop.getVariableName();
            String type         = prop.getType();
            String multiType    = prop.getMultiType();
            String multiVarName = HSStringUtil.ensureValidVariableName(prop.getMultiType(), "object");

            // First do shallow assignment
            buffer.append(indentString2 + codeVarName + " = other." + varName + ";\n");

            if (prop.isImmutableType()) {
                // We are immutable - shallow assignment is all we needed
            }
            else if (prop.isArray()) {
                // We are an array - copy the array, cloning each element (if non-null object)
                buffer.append(indentString2 + "if (other." + varName + " != null)\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + codeVarName + " = new " + multiType + "[other." + varName + ".length];\n");
                buffer.append(indentString3 + "\n");
                buffer.append(indentString3 + "for (int i = 0; i < other." + varName + ".length; i++)\n");
                buffer.append(indentString3 + "{\n");

                if (prop.isImmutableMultiType()) {
                    // Immutable multi-type - use plain assignment
                    buffer.append(indentString4 + codeVarName + "[i] = other." + varName + "[i];\n");
                }
                else {
                    // Object multi-type - use cloning (if not null)
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = other." + varName + "[i];\n");
                    buffer.append(indentString4 + "\n");
                    buffer.append(indentString4 + "// Note - this code will not compile unless " + prop.getMultiType() + " supports Cloneable\n");

                    if (E_HSTypes.isGenericObject(prop.getMultiType())) {
                        // No cast required
                        buffer.append(indentString4 + codeVarName + "[i] = ((" + multiVarName + " == null) ? null : (" + multiVarName + ".clone()));\n");
                    }
                    else {
                        // Cast to the appropriate multi-value type
                        buffer.append(indentString4 + codeVarName + "[i] = (" + multiType + ") ((" + multiVarName + " == null) ? null : (" + multiVarName + ".clone()));\n");
                    }
                }

                buffer.append(indentString3 + "}\n");
                buffer.append(indentString2 + "}\n");
            }
            else if (prop.isCollection()) {
                // We are a collection - copy the collection, cloning each element if not null (why isn't this the default for clone ?)
                // Note if we are a collection interface then use clone to do a shallow copy and then clear !!
                buffer.append(indentString2 + "if (other." + varName + " != null)\n");
                buffer.append(indentString2 + "{\n");

                if (E_HSTypes.isCollectionInterface(type)) {
                    buffer.append(indentString3 + "// Note - this code will not compile unless " + type + " supports Cloneable\n");
                    buffer.append(indentString3 + codeVarName + " = (" + type + ") other." + varName + ".clone();\n");
                    buffer.append(indentString3 + codeVarName + ".clear();\n");
                }
                else {
                    buffer.append(indentString3 + codeVarName + " = new " + type + "(other." + varName + ".size());\n");
                }

                buffer.append(indentString3 + "\n");
                buffer.append(indentString3 + "for (Iterator iter = other." + varName + ".iterator(); iter.hasNext(); )\n");
                buffer.append(indentString3 + "{\n");

                if (E_HSTypes.isGenericObject(prop.getMultiType())) {
                    // No cast required
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = iter.next();\n");
                }
                else {
                    // Cast to the appropriate multi-value type
                    buffer.append(indentString4 + prop.getMultiType() + " " + multiVarName + " = (" + prop.getMultiType() + ") iter.next();\n");
                }

                buffer.append(indentString4 + "\n");

                if (prop.isImmutableMultiType()) {
                    // Immutable so add directly
                    buffer.append(indentString4 + codeVarName + ".add(" + multiVarName + ");\n");
                }
                else {
                    // Clone object
                    buffer.append(indentString4 + "// Note - this code will not compile unless " + prop.getMultiType() + " supports Cloneable\n");
                    buffer.append(indentString4 + codeVarName + ".add((" + multiVarName + " == null) ? null : (" + multiVarName + ".clone()));\n");
                }

                buffer.append(indentString3 + "}\n");
                buffer.append(indentString2 + "}\n");
            }
            else {
                // We are just an object - use clone (if not null)
                buffer.append(indentString2 + "if (other." + varName + " != null)\n");
                buffer.append(indentString2 + "{\n");
                buffer.append(indentString3 + "// Note - this code will not compile unless " + type + " supports Cloneable\n");
                buffer.append(indentString3 + codeVarName + " = (" + type + ") other." + varName + ".clone();\n");
                buffer.append(indentString2 + "}\n");
            }
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the debug code for a list of properties.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the debug code
     */
    public static String getDebugCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Returns the debug string.\n");
        buffer.append(indentString1 + " * @return the debug string\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public String toString()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "StringBuffer buf = new StringBuffer();\n");
        buffer.append(indentString2 + "\n");

        // First find the longest property name (so we pad to this maximum)
        int padLength = 0;

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            int propLen = ((HSBeanProperty) iter.next()).getName().length();

            if (propLen > padLength) {
                padLength = propLen;
            }
        }

        for (Iterator iter = beanClass.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty prop  = (HSBeanProperty) iter.next();
            String codeVarName   = prop.getCodeVariableName();
            String propNameColon = HSStringUtil.padString(prop.getName() + ": ", padLength + 2);

            if (prop.isArray()) {
                // Handle simple case - one dimensional array
                if (options.isVerboseDebugListings()) {
                    buffer.append(indentString2 + "buf.append(\"" + propNameColon + "\\n\");\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "for (int i = 0; i < " + codeVarName + ".length; i++)\n");
                    buffer.append(indentString2 + "{\n");
                    buffer.append(indentString3 + "buf.append(\" + \");\n");
                    buffer.append(indentString3 + "buf.append(" + codeVarName + "[i]);\n");
                    buffer.append(indentString3 + "buf.append(\"\\n\");\n");
                    buffer.append(indentString2 + "}\n");
                    buffer.append(indentString2 + "\n");
                }
                else {
                    buffer.append(indentString2 + "buf.append(\"" + propNameColon + "[\");\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "for (int i = 0; i < " + codeVarName + ".length; i++)\n");
                    buffer.append(indentString2 + "{\n");
                    buffer.append(indentString3 + "buf.append((i > 0) ? \", \" : \"\");\n");
                    buffer.append(indentString3 + "buf.append(" + codeVarName + "[i]);\n");
                    buffer.append(indentString2 + "}\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "buf.append(\"]\\n\");\n");
                }
            }
            else if (prop.isCollection()) {
                // Handle simple case - ArrayList of plain objects
                if (options.isVerboseDebugListings()) {
                    buffer.append(indentString2 + "buf.append(\"" + propNameColon + "\\n\");\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "for (Iterator iter = " + codeVarName + ".iterator(); iter.hasNext(); )\n");
                    buffer.append(indentString2 + "{\n");
                    buffer.append(indentString3 + "buf.append(\" + \");\n");
                    buffer.append(indentString3 + "buf.append(iter.next());\n");
                    buffer.append(indentString3 + "buf.append(\"\\n\");\n");
                    buffer.append(indentString2 + "}\n");
                    buffer.append(indentString2 + "\n");
                }
                else {
                    buffer.append(indentString2 + "buf.append(\"" + propNameColon + "[\");\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "for (Iterator iter = " + codeVarName + ".iterator(); iter.hasNext(); )\n");
                    buffer.append(indentString2 + "{\n");
                    buffer.append(indentString3 + "buf.append(iter.next());\n");
                    buffer.append(indentString3 + "buf.append(iter.hasNext() ? \", \" : \"\");\n");
                    buffer.append(indentString2 + "}\n");
                    buffer.append(indentString2 + "\n");
                    buffer.append(indentString2 + "buf.append(\"]\\n\");\n");
                }
            }
            else {
                buffer.append(indentString2 + "buf.append(\"" + propNameColon + "\" + " + codeVarName + " + \"\\n\");\n");
            }
        }

        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return buf.toString();\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the normal (non-multi) getter code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the normal (non-multi) getter code
     */
    private static String getNormalGetterCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String methodPrefix  = "get";

        if (prop.getIsGetterMethod() && E_HSTypes.isNativeBoolean(prop.getType())) {
            methodPrefix = "is";
        }

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @return " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + prop.getType() + " " + methodPrefix + prop.getCapitalisedName() + "()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ";\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the normal (non-multi) setter code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the normal (non-multi) setter code
     */
    private static String getNormalSetterCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Sets " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getName() + " " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void set" + prop.getCapitalisedName() + "(" + prop.getType() + " " + prop.getName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + " = " + prop.getName() + ";\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi accessor code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param multiFlag the multi-flag to return the code for
     * @param options the options
     * @return the multi accessor code
     */
    private static String getMultiAccessorCode(HSBeanProperty prop, int multiFlag, HSBeanOptions options) {
        StringBuffer buffer = new StringBuffer();

        if ((multiFlag < 0) || (multiFlag >= E_HSTypes.NUMBER_MULTI_FLAGS)) {
            throw new IllegalArgumentException("Multi-flag constant must be between 0 and " + (E_HSTypes.NUMBER_MULTI_FLAGS - 1));
        }

        switch (multiFlag) {
            case E_HSTypes.MULTI_GET :
                buffer.append(getMultiGetCode(prop, options));
                break;

            case E_HSTypes.MULTI_GET_INDEX :
                buffer.append(getMultiGetIndexCode(prop, options));
                break;

            case E_HSTypes.MULTI_GET_ITERATOR :
                buffer.append(getMultiGetIteratorCode(prop, options));
                break;

            case E_HSTypes.MULTI_GET_ENUMERATION :
                buffer.append(getMultiGetEnumerationCode(prop, options));
                break;

            case E_HSTypes.MULTI_GET_COUNT :
                buffer.append(getMultiGetCountCode(prop, options));
                break;

            case E_HSTypes.MULTI_GET_AS_ARRAY :
                buffer.append(getMultiGetAsArrayCode(prop, options));
                break;

            case E_HSTypes.MULTI_INDEX_OF :
                buffer.append(getMultiIndexOfCode(prop, options));
                break;

            case E_HSTypes.MULTI_ACTUAL_INDEX_OF :
                buffer.append(getMultiActualIndexOfCode(prop, options));
                break;

            case E_HSTypes.MULTI_SET :
                buffer.append(getMultiSetCode(prop, options));
                break;

            case E_HSTypes.MULTI_SET_INDEX :
                buffer.append(getMultiSetIndexCode(prop, options));
                break;

            case E_HSTypes.MULTI_ADD :
                buffer.append(getMultiAddCode(prop, options));
                break;

            case E_HSTypes.MULTI_ADD_INDEX :
                buffer.append(getMultiAddIndexCode(prop, options));
                break;

            case E_HSTypes.MULTI_REMOVE :
                buffer.append(getMultiRemoveCode(prop, options));
                break;

            case E_HSTypes.MULTI_REMOVE_INDEX :
                buffer.append(getMultiRemoveIndexCode(prop, options));
                break;

            case E_HSTypes.MULTI_CLEAR :
                buffer.append(getMultiClearCode(prop, options));
                break;
        }

        return buffer.toString();
    }

    /**
     * Returns the multi-value get code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get code
     */
    private static String getMultiGetCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @return " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + prop.getType() + " get" + prop.getCapitalisedName() + "()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ";\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value get index code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get index code
     */
    private static String getMultiGetIndexCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets an element of " + prop.getDescription() + " at a given index.\n");
        buffer.append(indentString1 + " * @param index the index of the element to get\n");
        buffer.append(indentString1 + " * @return the element of " + prop.getDescription() + " at the given index\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + prop.getMultiType() + " get" + prop.getCapitalisedName() + "(int index)\n");
        buffer.append(indentString1 + "{\n");

        if (prop.isArray()) {
            buffer.append(indentString2 + "return " + prop.getCodeVariableName() + "[index];\n");
        }
        else if (E_HSTypes.isGenericObject(prop.getMultiType())) {
            // No cast required
            buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".get(index);\n");
        }
        else {
            // Cast to the appropriate multi-value type
            buffer.append(indentString2 + "return (" + prop.getMultiType() + ") " + prop.getCodeVariableName() + ".get(index);\n");
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value get iterator code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get iterator code
     */
    private static String getMultiGetIteratorCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets an iterator for " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @return an iterator for " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public Iterator get" + prop.getCapitalisedName() + "Iterator()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".iterator();\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value get enumeration code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get enumeration code
     */
    private static String getMultiGetEnumerationCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets an enumeration for " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @return an enumeration for " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public Enumeration get" + prop.getCapitalisedName() + "Enumeration()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".elements();\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value get count code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get count code
     */
    private static String getMultiGetCountCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets the number of elements in " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @return the number of elements in " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public int get" + prop.getCapitalisedName() + "Count()\n");
        buffer.append(indentString1 + "{\n");

        if (prop.isArray()) {
            buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".length;\n");
        }
        else {
            buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".size();\n");
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value get as array code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value get as array code
     */
    private static String getMultiGetAsArrayCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets " + prop.getDescription() + " as an array.\n");
        buffer.append(indentString1 + " * @return the " + prop.getDescription() + " as an array\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public " + prop.getMultiType() + "[] get" + prop.getCapitalisedName() + "AsArray()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "return (" + prop.getMultiType() + "[]) " + prop.getCodeVariableName() + ".toArray(new " + prop.getMultiType() + "[" + prop.getCodeVariableName() + ".size()]);\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value index of code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value index of code
     */
    private static String getMultiIndexOfCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets the index of a given element in " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element to search for\n");
        buffer.append(indentString1 + " * @return the index of the element in " + prop.getDescription() + " (-1 if not found)\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public int getIndexOf" + prop.getCapitalisedName() + "(" + prop.getMultiType() + " " + prop.getSingularName() + ")\n");
        buffer.append(indentString1 + "{\n");

        String method = "indexOf";

        if (options.getArrayUtilMethod().equals(E_HSArrayUtilMethod.CLASS)) {
            method = options.getArrayUtilClass() + ".indexOf";
        }

        if (prop.isArray()) {
            buffer.append(indentString2 + "return " + method + "(" + prop.getCodeVariableName() + ", " + prop.getSingularName() + ");\n");
        }
        else {
            buffer.append(indentString2 + "return " + prop.getCodeVariableName() + ".indexOf(" + prop.getSingularName() + ");\n");
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value actual index of code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value actual index of code
     */
    private static String getMultiActualIndexOfCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Gets the index of a given element in " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element to search for\n");
        buffer.append(indentString1 + " * @return the index of the element in " + prop.getDescription() + " (-1 if not found)\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public int getActualIndexOf" + prop.getCapitalisedName() + "(" + prop.getMultiType() + " " + prop.getSingularName() + ")\n");
        buffer.append(indentString1 + "{\n");

        String method = "actualIndexOf";

        if (options.getArrayUtilMethod().equals(E_HSArrayUtilMethod.CLASS)) {
            method = options.getArrayUtilClass() + ".actualIndexOf";
        }

        buffer.append(indentString2 + "return " + method + "(" + prop.getCodeVariableName() + ", " + prop.getSingularName() + ");\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value set code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value set code
     */
    private static String getMultiSetCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Sets " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getName() + " " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void set" + prop.getCapitalisedName() + "(" + prop.getType() + " " + prop.getName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + " = " + prop.getName() + ";\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value set index code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value set index code
     */
    private static String getMultiSetIndexCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Sets an element of " + prop.getDescription() + " at a given index.\n");
        buffer.append(indentString1 + " * @param index the index of the element to set\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element of " + prop.getDescription() + " to set at the given index\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void set" + prop.getCapitalisedName() + "(int index, " + prop.getMultiType() + " " + prop.getSingularName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");

        if (prop.isArray()) {
            buffer.append(indentString2 + prop.getCodeVariableName() + "[index] = " + prop.getSingularName() + ";\n");
        }
        else {
            buffer.append(indentString2 + prop.getCodeVariableName() + ".set(index, " + prop.getSingularName() + ");\n");
        }

        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value add code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value add code
     */
    private static String getMultiAddCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Adds an element to " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element to add to " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void add" + prop.getCapitalisedName() + "(" + prop.getMultiType() + " " + prop.getSingularName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + ".add(" + prop.getSingularName() + ");\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value add index code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value add index code
     */
    private static String getMultiAddIndexCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Adds an element to " + prop.getDescription() + " at a given index.\n");
        buffer.append(indentString1 + " * @param index the index of the element to add\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element to add to " + prop.getDescription() + " at the given index\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void add" + prop.getCapitalisedName() + "(int index, " + prop.getMultiType() + " " + prop.getSingularName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + ".add(index, " + prop.getSingularName() + ");\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value remove code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value remove code
     */
    private static String getMultiRemoveCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Removes an element from " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " * @param " + prop.getSingularName() + " the element to remove from " + prop.getDescription() + "\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void remove" + prop.getCapitalisedName() + "(" + prop.getMultiType() + " " + prop.getSingularName() + ")" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + ".remove(" + prop.getSingularName() + ");\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value remove index code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value remove index code
     */
    private static String getMultiRemoveIndexCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Removes an element from " + prop.getDescription() + " at a given index.\n");
        buffer.append(indentString1 + " * @param index the index of the element to remove\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void remove" + prop.getCapitalisedName() + "(int index)" + "\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + ".remove(index);\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Returns the multi-value clear code.
     *
     * @param prop the prop (HSBeanProperty) to return code for
     * @param options the options
     * @return the multi-value clear code
     */
    private static String getMultiClearCode(HSBeanProperty prop, HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Clears all elements from " + prop.getDescription() + ".\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + "public void clear" + prop.getCapitalisedName() + "()\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + prop.getCodeVariableName() + ".clear();\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");

        return buffer.toString();
    }

    /**
     * Return the hash string for a native type.
     *
     * @param buffer the string buffer (StringBuffer) to append the hash string to
     * @param varName the name of the variable
     * @param type the type of the variable
     * @param indentString1 the indentation string to use
     * @param longTempAdded whether a "long temp" variable has already been added
     * @return whether a "long temp" variable has already been added
     */
    private static boolean addNativeHashCodeString(StringBuffer buffer, String varName, String type, String indentString1, boolean longTempAdded) {
        // We have a native type - add it to our hashcode
        if (E_HSTypes.isNativeBoolean(type)) {
            buffer.append(indentString1 + "hashCode = (37 * hashCode) + (" + varName + " ? 0 : 1);\n");
        }
        else if (E_HSTypes.isNativeHashInt(type)) {
            if (E_HSTypes.isNativeInt(type)) {
                // No need for cast
                buffer.append(indentString1 + "hashCode = (37 * hashCode) + " + varName + ";\n");
            }
            else {
                // Cast to int
                buffer.append(indentString1 + "hashCode = (37 * hashCode) + (int) " + varName + ";\n");
            }
        }
        else if (E_HSTypes.isNativeLong(type)) {
            buffer.append(indentString1 + "hashCode = (37 * hashCode) + (int) (" + varName + " ^ (" + varName + " >>> 32));\n");
        }
        else if (E_HSTypes.isNativeFloat(type)) {
            buffer.append(indentString1 + "hashCode = (37 * hashCode) + Float.floatToIntBits(" + varName + ");\n");
        }
        else if (E_HSTypes.isNativeDouble(type)) {
            if (!longTempAdded) {
                buffer.append(indentString1 + "long temp = Double.doubleToLongBits(" + varName + ");\n");

                longTempAdded = true;
            }
            else {
                buffer.append(indentString1 + "temp = Double.doubleToLongBits(" + varName + ");\n");
            }

            buffer.append(indentString1 + "hashCode = (37 * hashCode) + (int) (temp ^ (temp >>> 32));\n");
        }
        else {
            // Should never get here...
            throw new Error("Unknown native type: " + type);
        }

        return longTempAdded;
    }

    /**
     * Returns the static utility code.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the static utility code
     */
    public static String getStaticUtilityCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        boolean first        = true;

        if (options.getObjectEqualityMethod().equals(E_HSObjectEqualityMethod.STATIC)) {
            buffer.append(HSBeanCodeGenerator.getObjectEqualityCode(options));

            first = false;
        }

        if (options.getArrayUtilMethod().equals(E_HSArrayUtilMethod.STATIC)) {
            if (!first) {
                buffer.append(indentString1 + "\n");
            }

            buffer.append(HSBeanCodeGenerator.getArrayUtilCode(options));
        }

        return buffer.toString();
    }

    /**
     * Returns the utility classes code.
     *
     * @param beanClass the bean class to return the code for
     * @param options the options
     * @return the utility classes code
     */
    public static String getUtilityClassesCode(HSBeanClass beanClass, HSBeanOptions options) {
        if (beanClass.getPropertiesCount() == 0) {
            return "";
        }

        String objectEqualityClass = (options.getObjectEqualityMethod().equals(E_HSObjectEqualityMethod.CLASS)) ? options.getObjectEqualityClass() : null;
        String arrayUtilClass      = (options.getArrayUtilMethod().equals(E_HSArrayUtilMethod.CLASS)) ? options.getArrayUtilClass() : null;

        if ((objectEqualityClass == null) && (arrayUtilClass == null)) {
            return "";
        }

        StringBuffer buffer  = new StringBuffer();
        String indentString0 = "";
        String indentString1 = options.getIndentString();

        if ((objectEqualityClass != null) && objectEqualityClass.equals(arrayUtilClass)) {
            // Combine in same class
            buffer.append(indentString0 + "public class " + objectEqualityClass + "\n");
            buffer.append(indentString0 + "{\n");
            buffer.append(getObjectEqualityCode(options));
            buffer.append(indentString1 + "\n");
            buffer.append(getArrayUtilCode(options));
            buffer.append(indentString0 + "}\n");
        }
        else {
            // In different classes - first the object equality class
            if (objectEqualityClass != null) {
                buffer.append(indentString0 + "public class " + objectEqualityClass + "\n");
                buffer.append(indentString0 + "{\n");
                buffer.append(getObjectEqualityCode(options));
                buffer.append(indentString0 + "}\n");
            }

            // And then the array util class
            if (arrayUtilClass != null) {
                if (objectEqualityClass != null) {
                    buffer.append(indentString0 + "\n");
                }

                buffer.append(indentString0 + "import java.util.*;\n");
                buffer.append(indentString0 + "\n");
                buffer.append(indentString0 + "public class " + arrayUtilClass + "\n");
                buffer.append(indentString0 + "{\n");
                buffer.append(getArrayUtilCode(options));
                buffer.append(indentString0 + "}\n");
            }
        }

        return buffer.toString();
    }

    /**
     * Returns the object equality class code.
     *
     * @param options the options
     * @return the object equality class code
     */
    private static String getObjectEqualityCode(HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;

        // Method is private if static, public if class
        String visibility = "private";

        if (options.getObjectEqualityMethod().equals(E_HSObjectEqualityMethod.CLASS)) {
            visibility = "public";
        }

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Compares two objects for equality, catering for nulls.\n");
        buffer.append(indentString1 + " * Why, why doesn't Java do this for you automagically.\n");
        buffer.append(indentString1 + " * @param o1 the first object\n");
        buffer.append(indentString1 + " * @param o2 the second object\n");
        buffer.append(indentString1 + " * @return whether the objects are equal\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + visibility + " static boolean equals(Object o1, Object o2)\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "if (o1 == o2)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "return true;\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return (o1 == null) ? (o2 == null) : (o1.equals(o2));\n");
        buffer.append(indentString1 + "}\n");

        return buffer.toString();
    }

    /**
     * Returns the array util class code.
     *
     * @param options the options
     * @return the array util class code
     */
    private static String getArrayUtilCode(HSBeanOptions options) {
        StringBuffer buffer  = new StringBuffer();
        String indentString1 = options.getIndentString();
        String indentString2 = indentString1 + indentString1;
        String indentString3 = indentString2 + indentString1;
        String indentString4 = indentString3 + indentString1;
        String indentString5 = indentString4 + indentString1;

        // Method is private if static, public if class
        String visibility = "private";

        if (options.getArrayUtilMethod().equals(E_HSArrayUtilMethod.CLASS)) {
            visibility = "public";
        }

        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Returns the index of an object in an object array. Uses equals,\n");
        buffer.append(indentString1 + " * just like List.indexOf(). Why don't arrays do this already :(\n");
        buffer.append(indentString1 + " * @param array the object array to look in\n");
        buffer.append(indentString1 + " * @param o the object to look for\n");
        buffer.append(indentString1 + " * @return the index of the object (or -1 if not found)\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + visibility + " static int indexOf(Object[] array, Object o)\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "if (array == null) {\n");
        buffer.append(indentString3 + "return -1;\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "int n = array.length;\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "if (o == null)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "for (int i = 0; i < n; i++) {\n");
        buffer.append(indentString4 + "if (array[i] == null)\n");
        buffer.append(indentString4 + "{\n");
        buffer.append(indentString5 + "return i;\n");
        buffer.append(indentString4 + "}\n");
        buffer.append(indentString3 + "}\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "else\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "for (int i = 0; i < n; i++)\n");
        buffer.append(indentString3 + "{\n");
        buffer.append(indentString4 + "if (o.equals(array[i]))\n");
        buffer.append(indentString4 + "{\n");
        buffer.append(indentString5 + "return i;\n");
        buffer.append(indentString4 + "}\n");
        buffer.append(indentString3 + "}\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return -1;\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");
        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Returns the index of an object in an object array. Does NOT use equals\n");
        buffer.append(indentString1 + " * (uses direct object comparison) unlike indexOf().\n");
        buffer.append(indentString1 + " * @param array the object array to look in\n");
        buffer.append(indentString1 + " * @param o the object to look for\n");
        buffer.append(indentString1 + " * @return the index of the object (or -1 if not found)\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + visibility + " static int actualIndexOf(Object[] array, Object o)\n");
        buffer.append(indentString1 + "{\n");
        buffer.append(indentString2 + "if (array == null)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "return -1;\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "int n = array.length;\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "for (int i = 0; i < n; i++)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "if (array[i] == o)\n");
        buffer.append(indentString3 + "{\n");
        buffer.append(indentString4 + "return i;\n");
        buffer.append(indentString3 + "}\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return -1;\n");
        buffer.append(indentString1 + "}\n");
        buffer.append(indentString1 + "\n");
        buffer.append(indentString1 + "/**\n");
        buffer.append(indentString1 + " * Returns the index of an object in a list. Does NOT use equals\n");
        buffer.append(indentString1 + " * (uses direct object comparison) unlike indexOf().\n");
        buffer.append(indentString1 + " * @param list the list to look in\n");
        buffer.append(indentString1 + " * @param o the object to look for\n");
        buffer.append(indentString1 + " * @return the index of the object (or -1 if not found)\n");
        buffer.append(indentString1 + " */\n");
        buffer.append(indentString1 + visibility + " static int actualIndexOf(List list, Object o) {\n");
        buffer.append(indentString2 + "if (list == null)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "return -1;\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "int n = list.size();\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "for (int i = 0; i < n; i++)\n");
        buffer.append(indentString2 + "{\n");
        buffer.append(indentString3 + "if (list.get(i) == o)\n");
        buffer.append(indentString3 + "{\n");
        buffer.append(indentString4 + "return i;\n");
        buffer.append(indentString3 + "}\n");
        buffer.append(indentString2 + "}\n");
        buffer.append(indentString2 + "\n");
        buffer.append(indentString2 + "return -1;\n");
        buffer.append(indentString1 + "}\n");

        return buffer.toString();
    }
}
