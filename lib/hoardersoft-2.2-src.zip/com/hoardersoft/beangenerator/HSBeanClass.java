package com.hoardersoft.beangenerator;

/**
 * Description for an bean class.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
import java.util.ArrayList;
import java.util.Iterator;

public class HSBeanClass {
    private String m_className     = "CustomBean";
    private ArrayList m_properties = new ArrayList();

    /**
     * Gets the class name property.
     *
     * @return the class name property
     */
    public String getClassName() {
        return m_className;
    }

    /**
     * Sets the class name property.
     *
     * @param className the class name property
     */
    public void setClassName(String className) {
        m_className = className;
    }

    /**
     * Gets an element of the properties property at a given index.
     *
     * @param index the index of the element to get
     * @return the element of the properties property at the given index
     */
    public HSBeanProperty getProperties(int index) {
        return (HSBeanProperty) m_properties.get(index);
    }

    /**
     * Gets an iterator for the properties property.
     *
     * @return an iterator for the properties property
     */
    public Iterator getPropertiesIterator() {
        return m_properties.iterator();
    }

    /**
     * Gets the number of elements in the properties property.
     *
     * @return the number of elements in the properties property
     */
    public int getPropertiesCount() {
        return m_properties.size();
    }

    /**
     * Adds an element to the properties property.
     *
     * @param propertie the element to add to the properties property
     */
    public void addProperties(HSBeanProperty propertie) {
        m_properties.add(propertie);
    }

    /**
     * Adds an element to the properties property at a given index.
     *
     * @param index the index of the element to add
     * @param propertie the element to add to the properties property at the given index
     */
    public void addProperties(int index, HSBeanProperty propertie) {
        m_properties.add(index, propertie);
    }

    /**
     * Removes an element from the properties property.
     *
     * @param propertie the element to remove from the properties property
     */
    public void removeProperties(HSBeanProperty propertie) {
        m_properties.remove(propertie);
    }

    /**
     * Removes an element from the properties property at a given index.
     *
     * @param index the index of the element to remove
     */
    public void removeProperties(int index) {
        m_properties.remove(index);
    }

    /**
     * Returns the properties property as an array.
     *
     * @return the properties property as an array
     */
    public HSBeanProperty[] getPropertiesAsArray() {
        return (HSBeanProperty[]) m_properties.toArray(new HSBeanProperty[0]);
    }
}
