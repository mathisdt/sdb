package com.hoardersoft.beangenerator;

/**
 * Options for the enum generator.
 *
 * <ul>
 *   <li>indentSize            - the indent size to use</li>
 *   <li>defaultVariablePrefix - the default variable prefix to use</li>
 *   <li>defaultIsGetter       - whether to create "is" getters by default</li>
 *   <li>objectEqualityMethod  - the object equality method (an E_HSObjectEqualityMethod value)</li>
 *   <li>objectEqualityClass   - if the object equality method is "CLASS" then the class name to use</li>
 * </ul>
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
import com.hoardersoft.util.HSLogUtil;

public class HSBeanOptions {
    private static final String PREFS_INDENT_SIZE             = "IndentSize";
    private static final String PREFS_DEFAULT_VARIABLE_PREFIX = "DefaultVariablePrefix";
    private static final String PREFS_DEFAULT_IS_GETTER       = "DefaultIsGetter";
    private static final String PREFS_VERBOSE_DEBUG_LISTINGS  = "VerboseDebugListings";
    private static final String PREFS_OBJECT_EQUALITY_CLASS   = "ObjectEqualityClass";
    private static final String PREFS_OBJECT_EQUALITY_METHOD  = "ObjectEqualityMethod";
    private static final String PREFS_ARRAY_UTIL_CLASS        = "ArrayUtilClass";
    private static final String PREFS_ARRAY_UTIL_METHOD       = "ArrayUtilMethod";
    private static final String PREFS_CONSTRUCTOR_METHOD      = "ConstructorMethod";
    private static final String PREFS_EQUALS_METHOD           = "EqualsMethod";
    private static final String PREFS_CLONE_METHOD            = "CloneMethod";
    private static final String PREFS_HASH_CODE_METHOD        = "HashCodeMethod";
    private static final String PREFS_COPY_METHOD             = "CopyMethod";
    private static final String PREFS_DEBUG_METHOD            = "DebugMethod";
    private int m_indentSize                                  = 4;
    private String m_indentString                             = "    ";
    private String m_defaultVariablePrefix                    = "m_";
    private boolean m_defaultIsGetter                         = true;
    private boolean m_verboseDebugListings                    = true;
    private E_HSObjectEqualityMethod m_objectEqualityMethod   = E_HSObjectEqualityMethod.CLASS;
    private String m_objectEqualityClass                      = "ObjectUtil";
    private E_HSArrayUtilMethod m_arrayUtilMethod             = E_HSArrayUtilMethod.CLASS;
    private String m_arrayUtilClass                           = "ArrayUtil";
    private boolean m_constructorMethod                       = false;
    private boolean m_equalsMethod                            = false;
    private boolean m_cloneMethod                             = false;
    private boolean m_hashCodeMethod                          = false;
    private boolean m_copyMethod                              = false;
    private boolean m_debugMethod                             = false;

    /**
     * Gets the indent size property.
     *
     * @return the indent size property
     */
    public int getIndentSize() {
        return m_indentSize;
    }

    /**
     * Gets the indent string property.
     *
     * @return the indent string property
     */
    public String getIndentString() {
        return m_indentString;
    }

    /**
     * Sets the indent size property.
     *
     * @param indentSize the indent size property
     */
    public void setIndentSize(int indentSize) {
        if (m_indentSize != indentSize) {
            m_indentSize = indentSize;

            // Set up the indent string
            StringBuffer buffer = new StringBuffer(indentSize);

            for (int i = 0; i < indentSize; i++) {
                buffer.append(" ");
            }

            m_indentString = buffer.toString();
        }
    }

    /**
     * Gets the default variable prefix property.
     *
     * @return the default variable prefix property
     */
    public String getDefaultVariablePrefix() {
        return m_defaultVariablePrefix;
    }

    /**
     * Sets the default variable prefix property.
     *
     * @param defaultVariablePrefix the default variable prefix property
     */
    public void setDefaultVariablePrefix(String defaultVariablePrefix) {
        m_defaultVariablePrefix = defaultVariablePrefix;
    }

    /**
     * Gets the default is getter property.
     *
     * @return the default is getter property
     */
    public boolean isDefaultIsGetter() {
        return m_defaultIsGetter;
    }

    /**
     * Sets the default is getter property.
     *
     * @param defaultIsGetter the default is getter property
     */
    public void setDefaultIsGetter(boolean defaultIsGetter) {
        m_defaultIsGetter = defaultIsGetter;
    }

    /**
     * Gets the verbose debug listings property.
     *
     * @return the verbose debug listings property
     */
    public boolean isVerboseDebugListings() {
        return m_verboseDebugListings;
    }

    /**
     * Sets the verbose debug listings property.
     *
     * @param verboseDebugListings the verbose debug listings property
     */
    public void setVerboseDebugListings(boolean verboseDebugListings) {
        m_verboseDebugListings = verboseDebugListings;
    }

    /**
     * Gets the object equality method property.
     *
     * @return the object equality method property
     */
    public E_HSObjectEqualityMethod getObjectEqualityMethod() {
        return m_objectEqualityMethod;
    }

    /**
     * Sets the object equality method property.
     *
     * @param objectEqualityMethod the object equality method property
     */
    public void setObjectEqualityMethod(E_HSObjectEqualityMethod objectEqualityMethod) {
        m_objectEqualityMethod = objectEqualityMethod;
    }

    /**
     * Gets the object equality class property.
     *
     * @return the object equality class property
     */
    public String getObjectEqualityClass() {
        return m_objectEqualityClass;
    }

    /**
     * Sets the object equality class property.
     *
     * @param objectEqualityClass the object equality class property
     */
    public void setObjectEqualityClass(String objectEqualityClass) {
        m_objectEqualityClass = objectEqualityClass;
    }

    /**
     * Gets the array util method property.
     *
     * @return the array util method property
     */
    public E_HSArrayUtilMethod getArrayUtilMethod() {
        return m_arrayUtilMethod;
    }

    /**
     * Sets the array util method property.
     *
     * @param arrayUtilMethod the array util method property
     */
    public void setArrayUtilMethod(E_HSArrayUtilMethod arrayUtilMethod) {
        m_arrayUtilMethod = arrayUtilMethod;
    }

    /**
     * Gets the array util class property.
     *
     * @return the array util class property
     */
    public String getArrayUtilClass() {
        return m_arrayUtilClass;
    }

    /**
     * Sets the array util class property.
     *
     * @param arrayUtilClass the array util class property
     */
    public void setArrayUtilClass(String arrayUtilClass) {
        m_arrayUtilClass = arrayUtilClass;
    }

    /**
     * Gets the constructor method property.
     *
     * @return the constructor method property
     */
    public boolean isConstructorMethod() {
        return m_constructorMethod;
    }

    /**
     * Sets the constructor method property.
     *
     * @param constructorMethod the constructor method property
     */
    public void setConstructorMethod(boolean constructorMethod) {
        m_constructorMethod = constructorMethod;
    }

    /**
     * Gets the equals method property.
     *
     * @return the equals method property
     */
    public boolean isEqualsMethod() {
        return m_equalsMethod;
    }

    /**
     * Sets the equals method property.
     *
     * @param equalsMethod the equals method property
     */
    public void setEqualsMethod(boolean equalsMethod) {
        m_equalsMethod = equalsMethod;
    }

    /**
     * Gets the clone method property.
     *
     * @return the clone method property
     */
    public boolean isCloneMethod() {
        return m_cloneMethod;
    }

    /**
     * Sets the clone method property.
     *
     * @param cloneMethod the clone method property
     */
    public void setCloneMethod(boolean cloneMethod) {
        m_cloneMethod = cloneMethod;
    }

    /**
     * Gets the hash code method property.
     *
     * @return the hash code method property
     */
    public boolean isHashCodeMethod() {
        return m_hashCodeMethod;
    }

    /**
     * Sets the hash code method property.
     *
     * @param hashCodeMethod the hash code method property
     */
    public void setHashCodeMethod(boolean hashCodeMethod) {
        m_hashCodeMethod = hashCodeMethod;
    }

    /**
     * Gets the copy method property.
     *
     * @return the copy method property
     */
    public boolean isCopyMethod() {
        return m_copyMethod;
    }

    /**
     * Sets the copy method property.
     *
     * @param copyMethod the copy method property
     */
    public void setCopyMethod(boolean copyMethod) {
        m_copyMethod = copyMethod;
    }

    /**
     * Gets the debug method property.
     *
     * @return the debug method property
     */
    public boolean isDebugMethod() {
        return m_debugMethod;
    }

    /**
     * Sets the debug method property.
     *
     * @param debugMethod the debug method property
     */
    public void setDebugMethod(boolean debugMethod) {
        m_debugMethod = debugMethod;
    }

    /**
     * Updates the options from the properties file.
     */
    public void updateFromPropertiesFile() {
        E_HSObjectEqualityMethod objectEqualityMethod = E_HSObjectEqualityMethod.fromString(HSLogUtil.getStringProperty(PREFS_OBJECT_EQUALITY_METHOD, null));
        E_HSArrayUtilMethod arrayUtilMethod           = E_HSArrayUtilMethod.fromString(HSLogUtil.getStringProperty(PREFS_ARRAY_UTIL_METHOD, null));

        m_indentSize            = HSLogUtil.getIntegerProperty(PREFS_INDENT_SIZE, m_indentSize);
        m_defaultVariablePrefix = HSLogUtil.getStringProperty(PREFS_DEFAULT_VARIABLE_PREFIX, m_defaultVariablePrefix);
        m_defaultIsGetter       = HSLogUtil.getBooleanProperty(PREFS_DEFAULT_IS_GETTER, m_defaultIsGetter);
        m_verboseDebugListings  = HSLogUtil.getBooleanProperty(PREFS_VERBOSE_DEBUG_LISTINGS, m_verboseDebugListings);
        m_objectEqualityMethod  = (objectEqualityMethod != null) ? objectEqualityMethod : m_objectEqualityMethod;
        m_objectEqualityClass   = HSLogUtil.getStringProperty(PREFS_OBJECT_EQUALITY_CLASS, m_objectEqualityClass);
        m_arrayUtilMethod       = (arrayUtilMethod != null) ? arrayUtilMethod : m_arrayUtilMethod;
        m_arrayUtilClass        = HSLogUtil.getStringProperty(PREFS_ARRAY_UTIL_CLASS, m_arrayUtilClass);
        m_constructorMethod     = HSLogUtil.getBooleanProperty(PREFS_CONSTRUCTOR_METHOD, m_constructorMethod);
        m_equalsMethod          = HSLogUtil.getBooleanProperty(PREFS_EQUALS_METHOD, m_equalsMethod);
        m_cloneMethod           = HSLogUtil.getBooleanProperty(PREFS_CLONE_METHOD, m_cloneMethod);
        m_hashCodeMethod        = HSLogUtil.getBooleanProperty(PREFS_HASH_CODE_METHOD, m_hashCodeMethod);
        m_copyMethod            = HSLogUtil.getBooleanProperty(PREFS_COPY_METHOD, m_copyMethod);
        m_debugMethod           = HSLogUtil.getBooleanProperty(PREFS_DEBUG_METHOD, m_debugMethod);
    }

    /**
     * Updates the properties file from the options.
     */
    public void updatePropertiesFile() {
        HSLogUtil.setIntegerProperty(PREFS_INDENT_SIZE, m_indentSize);
        HSLogUtil.setStringProperty(PREFS_DEFAULT_VARIABLE_PREFIX, m_defaultVariablePrefix);
        HSLogUtil.setBooleanProperty(PREFS_DEFAULT_IS_GETTER, m_defaultIsGetter);
        HSLogUtil.setBooleanProperty(PREFS_VERBOSE_DEBUG_LISTINGS, m_verboseDebugListings);
        HSLogUtil.setStringProperty(PREFS_OBJECT_EQUALITY_METHOD, m_objectEqualityMethod.toString());
        HSLogUtil.setStringProperty(PREFS_OBJECT_EQUALITY_CLASS, m_objectEqualityClass);
        HSLogUtil.setStringProperty(PREFS_ARRAY_UTIL_METHOD, m_arrayUtilMethod.toString());
        HSLogUtil.setStringProperty(PREFS_ARRAY_UTIL_CLASS, m_arrayUtilClass);
        HSLogUtil.setBooleanProperty(PREFS_CONSTRUCTOR_METHOD, m_constructorMethod);
        HSLogUtil.setBooleanProperty(PREFS_EQUALS_METHOD, m_equalsMethod);
        HSLogUtil.setBooleanProperty(PREFS_CLONE_METHOD, m_cloneMethod);
        HSLogUtil.setBooleanProperty(PREFS_HASH_CODE_METHOD, m_hashCodeMethod);
        HSLogUtil.setBooleanProperty(PREFS_COPY_METHOD, m_copyMethod);
        HSLogUtil.setBooleanProperty(PREFS_DEBUG_METHOD, m_debugMethod);
        HSLogUtil.saveProperties();
    }
}
