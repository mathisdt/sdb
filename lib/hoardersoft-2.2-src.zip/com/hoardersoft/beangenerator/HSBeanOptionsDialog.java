package com.hoardersoft.beangenerator;

import com.hoardersoft.util.HSMathUtil;
import com.hoardersoft.util.HSVerticalFlowLayout;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Dialog used to edit bean generator options.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSBeanOptionsDialog extends JDialog {
    // GUI members
    private JPanel m_panel                              = new JPanel(new BorderLayout());
    private JPanel m_prefsPanel                         = new JPanel(new HSVerticalFlowLayout());
    private JPanel m_buttonPanel                        = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    private JButton m_okButton                          = new JButton("OK");
    private JButton m_cancelButton                      = new JButton("Cancel");
    private JPanel m_indentSizePanel                    = new JPanel(new BorderLayout());
    private JLabel m_indentSizeLabel                    = new JLabel("Indent Size:");
    private JSlider m_indentSizeSlider                  = new JSlider();
    private JLabel m_indentSizeValueLabel               = new JLabel();
    private JPanel m_defaultVariablePrefixPanel         = new JPanel(new BorderLayout());
    private JLabel m_defaultVariablePrefixLabel         = new JLabel("Default Variable Prefix:");
    private JTextField m_defaultVariablePrefixTextField = new JTextField();
    private JPanel m_defaultIsGetterPanel               = new JPanel(new BorderLayout());
    private JLabel m_defaultIsGetterLabel               = new JLabel("Default Is Getter:");
    private JCheckBox m_defaultIsGetterCheckBox         = new JCheckBox();
    private JPanel m_verboseDebugListingsPanel          = new JPanel(new BorderLayout());
    private JLabel m_verboseDebugListingsLabel          = new JLabel("Verbose Debug Listings:");
    private JCheckBox m_verboseDebugListingsCheckBox    = new JCheckBox();
    private JPanel m_objectEqualityMethodPanel          = new JPanel(new BorderLayout());
    private JLabel m_objectEqualityMethodLabel          = new JLabel("Object Equality Method:");
    private JComboBox m_objectEqualityMethodCombo       = new JComboBox(E_HSObjectEqualityMethod.getPrintableVector());
    private JTextField m_objectEqualityClassTextField   = new JTextField();
    private JPanel m_arrayUtilMethodPanel               = new JPanel(new BorderLayout());
    private JLabel m_arrayUtilMethodLabel               = new JLabel("Array Utility Methods:");
    private JComboBox m_arrayUtilMethodCombo            = new JComboBox(E_HSArrayUtilMethod.getPrintableVector());
    private JTextField m_arrayUtilClassTextField        = new JTextField();

    // Non-GUI members
    private boolean m_okPressed = false;

    /**
     * Class constructor.
     */
    public HSBeanOptionsDialog() {
        super();

        init();
    }

    /**
     * Class constructor that takes a parent dialog.
     *
     * @param dialog the parent dialog (Dialog)
     */
    public HSBeanOptionsDialog(Dialog dialog) {
        super(dialog);

        init();
    }

    /**
     * Class constructor that takes a parent frame.
     *
     * @param frame the parent frame (Frame)
     */
    public HSBeanOptionsDialog(Frame frame) {
        super(frame);

        init();
    }

    /**
     * Initialise the GUI.
     */
    private void init() {
        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            throw new Error("Error initialising GUI - HSBeanOptionsDialog");
        }
    }

    /**
     * Show the dialog.
     *
     * @param options the options
     * @return whether the OK button was pressed or not
     */
    public boolean showDialog(HSBeanOptions options) {
        // Update the GUI - limit our indent size to 0 to 20
        m_indentSizeSlider.setValue(HSMathUtil.checkRange(options.getIndentSize(), 0, 20));
        m_defaultVariablePrefixTextField.setText(options.getDefaultVariablePrefix());
        m_defaultIsGetterCheckBox.setSelected(options.isDefaultIsGetter());
        m_verboseDebugListingsCheckBox.setSelected(options.isVerboseDebugListings());
        m_objectEqualityMethodCombo.setSelectedIndex(options.getObjectEqualityMethod().toInt());
        m_objectEqualityClassTextField.setText(options.getObjectEqualityClass());
        m_objectEqualityClassTextField.setEnabled(m_objectEqualityMethodCombo.getSelectedIndex() == E_HSObjectEqualityMethod.CLASS.toInt());
        m_arrayUtilMethodCombo.setSelectedIndex(options.getArrayUtilMethod().toInt());
        m_arrayUtilClassTextField.setText(options.getArrayUtilClass());
        m_arrayUtilClassTextField.setEnabled(m_arrayUtilMethodCombo.getSelectedIndex() == E_HSArrayUtilMethod.CLASS.toInt());

        if (getParent() != null) {
            setLocationRelativeTo(getParent());
        }

        setVisible(true);

        if (m_okPressed) {
            E_HSObjectEqualityMethod objectEqualityMethod = E_HSObjectEqualityMethod.fromInt(m_objectEqualityMethodCombo.getSelectedIndex());
            E_HSArrayUtilMethod arrayUtilMethod           = E_HSArrayUtilMethod.fromInt(m_arrayUtilMethodCombo.getSelectedIndex());

            options.setIndentSize(m_indentSizeSlider.getValue());
            options.setDefaultVariablePrefix(m_defaultVariablePrefixTextField.getText().trim());
            options.setDefaultIsGetter(m_defaultIsGetterCheckBox.isSelected());
            options.setVerboseDebugListings(m_verboseDebugListingsCheckBox.isSelected());
            options.setObjectEqualityMethod((objectEqualityMethod != null) ? objectEqualityMethod : options.getObjectEqualityMethod());
            options.setObjectEqualityClass(m_objectEqualityClassTextField.getText().trim());
            options.setArrayUtilMethod((arrayUtilMethod != null) ? arrayUtilMethod : options.getArrayUtilMethod());
            options.setArrayUtilClass(m_arrayUtilClassTextField.getText().trim());
        }

        return m_okPressed;
    }

    // ---------------------------------------------------------------------------------
    // All code beneath here is GUI callback code
    // ---------------------------------------------------------------------------------
    private void m_indentSizeSlider_stateChanged() {
        m_indentSizeValueLabel.setText(String.valueOf(m_indentSizeSlider.getValue()));
    }

    private void m_objectEqualityMethodCombo_actionPerformed() {
        m_objectEqualityClassTextField.setEnabled(m_objectEqualityMethodCombo.getSelectedIndex() == E_HSObjectEqualityMethod.CLASS.toInt());
    }

    private void m_arrayUtilMethodCombo_actionPerformed() {
        m_arrayUtilClassTextField.setEnabled(m_arrayUtilMethodCombo.getSelectedIndex() == E_HSArrayUtilMethod.CLASS.toInt());
    }

    private void m_okButton_actionPerformed() {
        m_okPressed = true;

        dispose();
    }

    private void m_cancelButton_actionPerformed() {
        m_okPressed = false;

        dispose();
    }

    private void jbInit() {
        getContentPane().add(m_panel);
        m_panel.add(m_prefsPanel, BorderLayout.CENTER);
        m_panel.add(m_buttonPanel, BorderLayout.SOUTH);
        m_prefsPanel.add(m_indentSizePanel, null);
        m_prefsPanel.add(m_defaultVariablePrefixPanel, null);
        m_prefsPanel.add(m_defaultIsGetterPanel, null);
        m_prefsPanel.add(m_verboseDebugListingsPanel, null);
        m_prefsPanel.add(m_objectEqualityMethodPanel, null);
        m_prefsPanel.add(m_arrayUtilMethodPanel, null);
        m_indentSizePanel.add(m_indentSizeSlider, BorderLayout.CENTER);
        m_indentSizePanel.add(m_indentSizeLabel, BorderLayout.WEST);
        m_indentSizePanel.add(m_indentSizeValueLabel, BorderLayout.EAST);
        m_indentSizeLabel.setPreferredSize(new Dimension(130, 21));
        m_indentSizeSlider.setMaximum(20);
        m_indentSizeSlider.setPreferredSize(new Dimension(100, 21));
        m_indentSizeSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                m_indentSizeSlider_stateChanged();
            }
        });
        m_indentSizeValueLabel.setPreferredSize(new Dimension(15, 21));
        m_defaultVariablePrefixPanel.add(m_defaultVariablePrefixLabel, BorderLayout.WEST);
        m_defaultVariablePrefixPanel.add(m_defaultVariablePrefixTextField, BorderLayout.CENTER);
        m_defaultVariablePrefixLabel.setPreferredSize(new Dimension(130, 21));
        m_defaultIsGetterPanel.add(m_defaultIsGetterLabel, BorderLayout.WEST);
        m_defaultIsGetterPanel.add(m_defaultIsGetterCheckBox, BorderLayout.CENTER);
        m_defaultIsGetterLabel.setPreferredSize(new Dimension(130, 21));
        m_verboseDebugListingsPanel.add(m_verboseDebugListingsLabel, BorderLayout.WEST);
        m_verboseDebugListingsPanel.add(m_verboseDebugListingsCheckBox, BorderLayout.CENTER);
        m_verboseDebugListingsLabel.setPreferredSize(new Dimension(130, 21));
        m_objectEqualityMethodPanel.add(m_objectEqualityMethodLabel, BorderLayout.WEST);
        m_objectEqualityMethodPanel.add(m_objectEqualityMethodCombo, BorderLayout.CENTER);
        m_objectEqualityMethodPanel.add(m_objectEqualityClassTextField, BorderLayout.EAST);
        m_objectEqualityMethodLabel.setPreferredSize(new Dimension(130, 21));
        m_objectEqualityMethodCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_objectEqualityMethodCombo_actionPerformed();
            }
        });
        m_objectEqualityClassTextField.setPreferredSize(new Dimension(60, 21));
        m_arrayUtilMethodPanel.add(m_arrayUtilMethodLabel, BorderLayout.WEST);
        m_arrayUtilMethodPanel.add(m_arrayUtilMethodCombo, BorderLayout.CENTER);
        m_arrayUtilMethodPanel.add(m_arrayUtilClassTextField, BorderLayout.EAST);
        m_arrayUtilMethodLabel.setPreferredSize(new Dimension(130, 21));
        m_arrayUtilMethodCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_arrayUtilMethodCombo_actionPerformed();
            }
        });
        m_arrayUtilClassTextField.setPreferredSize(new Dimension(60, 21));
        m_buttonPanel.add(m_okButton, null);
        m_buttonPanel.add(m_cancelButton, null);
        m_okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_okButton_actionPerformed();
            }
        });
        m_cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_cancelButton_actionPerformed();
            }
        });
        setModal(true);
        setResizable(false);
        setTitle("Options");
    }
}
