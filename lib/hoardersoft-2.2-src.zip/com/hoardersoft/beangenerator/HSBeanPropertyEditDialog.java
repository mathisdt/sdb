package com.hoardersoft.beangenerator;

import com.hoardersoft.util.HSTextField;
import com.hoardersoft.util.HSVerticalFlowLayout;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class representing the bean property edit dialog.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSBeanPropertyEditDialog extends JDialog {
    // GUI members
    private JPanel m_panel                     = new JPanel(new HSVerticalFlowLayout(0, 5));
    private JPanel m_topPanel                  = new JPanel(new BorderLayout());
    private JPanel m_middlePanel               = new JPanel(new GridLayout(1, 2, 5, 0));
    private JPanel m_bottomPanel               = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    private JPanel m_labelPanel                = new JPanel(new HSVerticalFlowLayout());
    private JPanel m_settingsPanel             = new JPanel(new HSVerticalFlowLayout());
    private JLabel m_nameLabel                 = new JLabel("Name:");
    private JLabel m_typeLabel                 = new JLabel("Type:");
    private JLabel m_multiTypeLabel            = new JLabel("Multi Type:");
    private JLabel m_descriptionLabel          = new JLabel("Description:");
    private JLabel m_variableNameLabel         = new JLabel("Variable Name:");
    private JLabel m_singularNameLabel         = new JLabel("Singular Name:");
    private JLabel m_modeLabel                 = new JLabel("Mode:");
    private JLabel m_isGetterLabel             = new JLabel("Is Getter:");
    private JTextField m_nameTextField         = new HSTextField();
    private JTextField m_typeTextField         = new HSTextField();
    private JTextField m_multiTypeTextField    = new HSTextField();
    private JTextField m_descriptionTextField  = new HSTextField();
    private JTextField m_variableNameTextField = new HSTextField();
    private JTextField m_singularNameTextField = new HSTextField();
    private JComboBox m_modeComboBox           = new JComboBox();
    private JCheckBox m_isGetterCheckBox       = new JCheckBox();
    private JPanel m_multiReadPanel            = new JPanel(new HSVerticalFlowLayout(5, 0));
    private JPanel m_multiWritePanel           = new JPanel(new HSVerticalFlowLayout(5, 0));
    private JCheckBox m_getCheckBox            = new JCheckBox("Get");
    private JCheckBox m_getByIndexCheckBox     = new JCheckBox("Get by Index");
    private JCheckBox m_getIteratorCheckBox    = new JCheckBox("Get Iterator");
    private JCheckBox m_getEnumerationCheckBox = new JCheckBox("Get Enumeration");
    private JCheckBox m_getCountCheckBox       = new JCheckBox("Get Count");
    private JCheckBox m_getAsArrayCheckBox     = new JCheckBox("Get as Array");
    private JCheckBox m_indexOfCheckBox        = new JCheckBox("Index Of");
    private JCheckBox m_actualIndexOfCheckBox  = new JCheckBox("Actual Index Of");
    private JCheckBox m_setCheckBox            = new JCheckBox("Set");
    private JCheckBox m_setByIndexCheckBox     = new JCheckBox("Set by Index");
    private JCheckBox m_addCheckBox            = new JCheckBox("Add");
    private JCheckBox m_addByIndexCheckBox     = new JCheckBox("Add by Index");
    private JCheckBox m_removeCheckBox         = new JCheckBox("Remove");
    private JCheckBox m_removeByIndexCheckBox  = new JCheckBox("Remove by Index");
    private JCheckBox m_clearCheckBox          = new JCheckBox("Clear");
    private JButton m_okButton                 = new JButton("OK");
    private JButton m_cancelButton             = new JButton("Cancel");

    // Non-GUI members
    private JCheckBox m_checkBoxes[]          = new JCheckBox[E_HSTypes.NUMBER_MULTI_FLAGS];
    private HSBeanProperty m_propertyOriginal = null;
    private HSBeanProperty m_property         = null;
    private boolean m_okPressed               = false;

    /**
     * Class constructor.
     */
    public HSBeanPropertyEditDialog() {
        super();

        init(null);
    }

    /**
     * Class constructor that takes a parent dialog and initial property.
     *
     * @param dialog the parent dialog (Dialog)
     * @param property the property this GUI is editing
     */
    public HSBeanPropertyEditDialog(Dialog dialog, HSBeanProperty property) {
        super(dialog);

        init(property);
    }

    /**
     * Class constructor that takes a parent frame and initial property.
     *
     * @param frame the parent frame (Frame)
     * @param property the property this GUI is editing
     */
    public HSBeanPropertyEditDialog(Frame frame, HSBeanProperty property) {
        super(frame);

        init(property);
    }

    /**
     * Initialise the GUI.
     *
     * @param property the property this GUI is editing
     */
    private void init(HSBeanProperty property) {
        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            throw new Error("Error initialising GUI - HSBeanPropertyEditDialog");
        }

        // Set up our mode combo
        m_modeComboBox.addItem("Read Only");
        m_modeComboBox.addItem("Write Only");
        m_modeComboBox.addItem("Read/Write");

        // Stash our original property and create a clone to work with
        m_propertyOriginal = property;
        m_property         = (HSBeanProperty) property.clone();

        // Set up our array for the checkboxes
        m_checkBoxes[E_HSTypes.MULTI_GET]             = m_getCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_GET_INDEX]       = m_getByIndexCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_GET_ITERATOR]    = m_getIteratorCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_GET_ENUMERATION] = m_getEnumerationCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_GET_COUNT]       = m_getCountCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_GET_AS_ARRAY]    = m_getAsArrayCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_INDEX_OF]        = m_indexOfCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_ACTUAL_INDEX_OF] = m_actualIndexOfCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_SET]             = m_setCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_SET_INDEX]       = m_setByIndexCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_ADD]             = m_addCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_ADD_INDEX]       = m_addByIndexCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_REMOVE]          = m_removeCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_REMOVE_INDEX]    = m_removeByIndexCheckBox;
        m_checkBoxes[E_HSTypes.MULTI_CLEAR]           = m_clearCheckBox;

        // Add listeners to the checkboxes
        ActionListener checkBoxListener = new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                Object source = a.getSource();

                for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
                    if (source == m_checkBoxes[i]) {
                        multiCheckBoxClicked(i);
                    }
                }
            }
        };

        for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
            m_checkBoxes[i].addActionListener(checkBoxListener);
        }

        updateGUI();
    }

    /**
     * Show the dialog.
     *
     * @return whether the OK button was pressed or not
     */
    public boolean showDialog() {
        if (getParent() != null) {
            setLocationRelativeTo(getParent());
        }

        setVisible(true);

        if (m_okPressed) {
            // Update our original property
            m_propertyOriginal.copy(m_property);
        }

        return m_okPressed;
    }

    /**
     * Update the GUI from the cloned property.
     */
    private void updateGUI() {
        boolean multiValue    = m_property.isMultiValue();
        boolean array         = m_property.isArray();
        boolean nativeBoolean = E_HSTypes.isNativeBoolean(m_property.getType());
        boolean isGetter      = nativeBoolean && m_property.isReadAllowed();

        // Set the window title
        setTitle("Edit Property - " + m_property.getName());

        // First the basic name and type fields
        m_nameTextField.setText(m_property.getName());
        m_typeTextField.setText(m_property.getType());

        // Now show our multi-type (if valid)
        m_multiTypeLabel.setEnabled(multiValue && !array);
        m_multiTypeTextField.setEnabled(multiValue && !array);
        m_multiTypeTextField.setText(multiValue ? m_property.getMultiType() : "");

        // Now the basic description and variable name
        m_descriptionTextField.setText(m_property.getDescription());
        m_variableNameTextField.setText(m_property.getVariableName());

        // And now the singular name (if valid)
        m_singularNameLabel.setEnabled(multiValue);
        m_singularNameTextField.setEnabled(multiValue);
        m_singularNameTextField.setText(multiValue ? m_property.getSingularName() : "");

        // And the mode combo and "is getter" toggle
        m_modeComboBox.setSelectedIndex(m_property.getMode());
        m_isGetterLabel.setEnabled(isGetter);
        m_isGetterCheckBox.setEnabled(isGetter);
        m_isGetterCheckBox.setSelected(isGetter ? m_property.getIsGetterMethod() : false);

        // Finally update all our toggles
        for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
            boolean valid = m_property.isMultiValid(i);

            m_checkBoxes[i].setEnabled(valid);
            m_checkBoxes[i].setSelected(valid ? m_property.getMultiFlag(i) : false);
        }
    }

    /**
     * Update the name.
     */
    private void updateName() {
        m_property.setName(m_nameTextField.getText());
        updateGUI();
    }

    /**
     * Update the type.
     */
    private void updateType() {
        m_property.setType(m_typeTextField.getText());
        updateGUI();
    }

    /**
     * Update the multi-value type.
     */
    private void updateMultiType() {
        m_property.setMultiType(m_multiTypeTextField.getText());
        updateGUI();
    }

    /**
     * Update the description.
     */
    private void updateDescription() {
        m_property.setDescription(m_descriptionTextField.getText());
        updateGUI();
    }

    /**
     * Update the variable name.
     */
    private void updateVariableName() {
        m_property.setVariableName(m_variableNameTextField.getText());
        updateGUI();
    }

    /**
     * Update the singular name.
     */
    private void updateSingularName() {
        m_property.setSingularName(m_singularNameTextField.getText());
        updateGUI();
    }

    /**
     * Update the mode.
     */
    private void updateMode() {
        // Need to protect against property being null - stupid Swing calls this when adding items :(
        if (m_property != null) {
            m_property.setMode(m_modeComboBox.getSelectedIndex());
            updateGUI();
        }
    }

    /**
     * Update the "is getter" flag.
     */
    private void updateIsGetter() {
        m_property.setIsGetterMethod(m_isGetterCheckBox.isSelected());
        updateGUI();
    }

    /**
     * Called when a multi-value checkbox is clicked. Note - assumes multiFlag is valid.
     *
     * @param multiFlag the multi-flag for the clicked checkbox
     */
    private void multiCheckBoxClicked(int multiFlag) {
        m_property.setMultiFlag(multiFlag, m_checkBoxes[multiFlag].isSelected());
    }

    // ---------------------------------------------------------------------------------
    // All code beneath here is GUI callback code
    // ---------------------------------------------------------------------------------
    private void m_nameTextField_actionPerformed() {
        updateName();
    }

    private void m_typeTextField_actionPerformed() {
        updateType();
    }

    private void m_multiTypeTextField_actionPerformed() {
        updateMultiType();
    }

    private void m_descriptionTextField_actionPerformed() {
        updateDescription();
    }

    private void m_variableNameTextField_actionPerformed() {
        updateVariableName();
    }

    private void m_singularNameTextField_actionPerformed() {
        updateSingularName();
    }

    private void m_modeComboBox_actionPerformed() {
        updateMode();
    }

    private void m_isGetterCheckBox_actionPerformed() {
        updateIsGetter();
    }

    private void m_okButton_actionPerformed() {
        m_okPressed = true;

        dispose();
    }

    private void m_cancelButton_actionPerformed() {
        m_okPressed = false;

        dispose();
    }

    private void jbInit() {
        getContentPane().add(m_panel, BorderLayout.CENTER);
        m_panel.add(m_topPanel, null);
        m_panel.add(m_middlePanel, null);
        m_panel.add(m_bottomPanel, null);
        m_topPanel.add(m_labelPanel, BorderLayout.WEST);
        m_topPanel.add(m_settingsPanel, BorderLayout.CENTER);
        m_labelPanel.add(m_nameLabel, null);
        m_labelPanel.add(m_typeLabel, null);
        m_labelPanel.add(m_multiTypeLabel, null);
        m_labelPanel.add(m_descriptionLabel, null);
        m_labelPanel.add(m_variableNameLabel, null);
        m_labelPanel.add(m_singularNameLabel, null);
        m_labelPanel.add(m_modeLabel, null);
        m_labelPanel.add(m_isGetterLabel, null);
        m_settingsPanel.add(m_nameTextField, null);
        m_settingsPanel.add(m_typeTextField, null);
        m_settingsPanel.add(m_multiTypeTextField, null);
        m_settingsPanel.add(m_descriptionTextField, null);
        m_settingsPanel.add(m_variableNameTextField, null);
        m_settingsPanel.add(m_singularNameTextField, null);
        m_settingsPanel.add(m_modeComboBox, null);
        m_settingsPanel.add(m_isGetterCheckBox, null);
        m_nameLabel.setPreferredSize(new Dimension(100, 21));
        m_nameTextField.setPreferredSize(new Dimension(100, 21));
        m_nameTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_nameTextField_actionPerformed();
            }
        });
        m_typeLabel.setPreferredSize(new Dimension(100, 21));
        m_typeTextField.setPreferredSize(new Dimension(100, 21));
        m_typeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_typeTextField_actionPerformed();
            }
        });
        m_multiTypeLabel.setPreferredSize(new Dimension(100, 21));
        m_multiTypeTextField.setPreferredSize(new Dimension(100, 21));
        m_multiTypeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_multiTypeTextField_actionPerformed();
            }
        });
        m_descriptionLabel.setPreferredSize(new Dimension(100, 21));
        m_descriptionTextField.setPreferredSize(new Dimension(100, 21));
        m_descriptionTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_descriptionTextField_actionPerformed();
            }
        });
        m_variableNameLabel.setPreferredSize(new Dimension(100, 21));
        m_variableNameTextField.setPreferredSize(new Dimension(100, 21));
        m_variableNameTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_variableNameTextField_actionPerformed();
            }
        });
        m_singularNameLabel.setPreferredSize(new Dimension(100, 21));
        m_singularNameTextField.setPreferredSize(new Dimension(100, 21));
        m_singularNameTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_singularNameTextField_actionPerformed();
            }
        });
        m_modeLabel.setPreferredSize(new Dimension(100, 21));
        m_modeComboBox.setPreferredSize(new Dimension(100, 21));
        m_modeComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_modeComboBox_actionPerformed();
            }
        });
        m_isGetterLabel.setPreferredSize(new Dimension(100, 21));
        m_isGetterCheckBox.setPreferredSize(new Dimension(100, 21));
        m_isGetterCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_isGetterCheckBox_actionPerformed();
            }
        });
        m_middlePanel.add(m_multiReadPanel, null);
        m_middlePanel.add(m_multiWritePanel, null);
        m_multiReadPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(148, 145, 140)), "Multi-Read"));
        m_multiReadPanel.add(m_getCheckBox, null);
        m_multiReadPanel.add(m_getByIndexCheckBox, null);
        m_multiReadPanel.add(m_getIteratorCheckBox, null);
        m_multiReadPanel.add(m_getEnumerationCheckBox, null);
        m_multiReadPanel.add(m_getCountCheckBox, null);
        m_multiReadPanel.add(m_getAsArrayCheckBox, null);
        m_multiReadPanel.add(m_indexOfCheckBox, null);
        m_multiReadPanel.add(m_actualIndexOfCheckBox, null);
        m_multiWritePanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(148, 145, 140)), "Multi-Write"));
        m_multiWritePanel.add(m_setCheckBox, null);
        m_multiWritePanel.add(m_setByIndexCheckBox, null);
        m_multiWritePanel.add(m_addCheckBox, null);
        m_multiWritePanel.add(m_addByIndexCheckBox, null);
        m_multiWritePanel.add(m_removeCheckBox, null);
        m_multiWritePanel.add(m_removeByIndexCheckBox, null);
        m_multiWritePanel.add(m_clearCheckBox, null);
        m_bottomPanel.add(m_okButton, null);
        m_bottomPanel.add(m_cancelButton, null);
        m_okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_okButton_actionPerformed();
            }
        });
        m_cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_cancelButton_actionPerformed();
            }
        });
        setModal(true);
        setResizable(false);
        setTitle("Edit Property");
    }
}
