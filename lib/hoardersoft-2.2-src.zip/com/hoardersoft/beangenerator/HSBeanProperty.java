package com.hoardersoft.beangenerator;

import com.hoardersoft.util.HSStringUtil;

/**
 * Class representing a bean property.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSBeanProperty implements Cloneable {
    // Static constants used for the mode
    static private final int READ_ONLY  = 0;
    static private final int WRITE_ONLY = 1;
    static private final int READ_WRITE = 2;

    // Property is defined by these
    private String m_name               = "";
    private String m_type               = "";
    private String m_multiType          = "";
    private String m_description        = "";
    private String m_variableName       = "";
    private String m_singularName       = "";
    private int m_mode                  = READ_WRITE;
    private boolean m_isGetterMethod    = false;
    private boolean[] m_multiFlags      = new boolean[E_HSTypes.NUMBER_MULTI_FLAGS];
    private HSBeanOptions m_beanOptions = null;

    // Convienience flags - derived from the above members
    private String m_capitalisedName     = "";
    private boolean m_nativeType         = false;
    private boolean m_nativeMultiType    = false;
    private boolean m_immutableType      = false;
    private boolean m_immutableMultiType = false;
    private boolean m_multiValue         = false;
    private boolean m_array              = false;
    private boolean m_collection         = false;
    private boolean m_list               = false;
    private boolean m_set                = false;
    private boolean m_vector             = false;

    // Not really part of a property bu useful for the overall application
    private int m_caretStartPosition = 0;
    private int m_caretEndPosition   = 0;

    /**
     * Class contructor that takes in a name and type.
     *
     * @param name the property name
     * @param type the property type
     */
    public HSBeanProperty(String name, String type, HSBeanOptions options) {
        // Stash a reference to our options
        m_beanOptions = options;

        // Set our name and type
        setName(name);
        setType(type);

        // Set up the default is getter flag
        m_isGetterMethod = m_beanOptions.isDefaultIsGetter();

        // Set up the default multi-flags (all false except basic get/set operations)
        for (int i = 0; i < E_HSTypes.NUMBER_MULTI_FLAGS; i++) {
            setMultiFlag(i, false);
        }

        setMultiFlag(E_HSTypes.MULTI_GET, true);
        setMultiFlag(E_HSTypes.MULTI_SET, true);
    }

    /**
     * Gets the property name.
     *
     * @return the property name
     */
    public String getName() {
        return m_name;
    }

    /**
     * Sets the property name.
     *
     * @param name the property name
     */
    public void setName(String name) {
        if (name.equals(m_name)) {
            // No change - just return
            return;
        }

        // Before we start - we don't want spaces or other odd characters !!
        m_name = HSStringUtil.ensureValidIdentifier(name, m_name);

        // Next ensure the name doesn't start with a capital
        m_name = HSStringUtil.ensureFirstLetterCase(m_name, false);

        // Work out the capitalised name
        m_capitalisedName = HSStringUtil.ensureFirstLetterCase(m_name, true);

        // We can set our default description from the name
        setDescription(HSStringUtil.getDefaultDescription(m_name));

        // Set our variable name
        setVariableName(m_beanOptions.getDefaultVariablePrefix() + m_name);

        // Set our singular name
        setSingularName(HSStringUtil.ensureSingular(m_name));
    }

    /**
     * Gets the property type.
     *
     * @return the property type
     */
    public String getType() {
        return m_type;
    }

    /**
     * Sets the property type.
     *
     * @param type the property type
     */
    public void setType(String type) {
        // Before we start - we don't want spaces or other odd characters !!
        m_type = HSStringUtil.ensureValidType(type, m_type);

        // Now update our flags
        m_nativeType    = E_HSTypes.isNative(m_type);
        m_immutableType = E_HSTypes.isImmutable(m_type);

        // Check for array type
        if (E_HSTypes.isArray(m_type)) {
            m_multiValue = true;
            m_collection = false;
            m_list       = false;
            m_set        = false;
            m_vector     = false;
            m_array      = true;

            // Work out our multi-type
            setMultiType(E_HSTypes.getArrayMultiType(m_type));
        }
        else if (E_HSTypes.isCollection(m_type)) {
            m_multiValue = true;
            m_collection = true;
            m_list       = E_HSTypes.isList(m_type);
            m_set        = E_HSTypes.isSet(m_type);
            m_vector     = E_HSTypes.isVector(m_type);
            m_array      = false;

            // Update our multi-type to check it is OK
            setMultiType(m_multiType);
        }
        else {
            m_multiValue = false;
            m_collection = false;
            m_list       = false;
            m_set        = false;
            m_vector     = false;
            m_array      = false;

            // Update our multi-type to check it is OK
            setMultiType(m_multiType);
        }
    }

    /**
     * Gets the property multi-value type.
     *
     * @return the property multi-value type
     */
    public String getMultiType() {
        return m_multiType;
    }

    /**
     * Sets the property multi-value type.
     *
     * @param multiType the property multi-value type
     */
    public void setMultiType(String multiType) {
        // Before we start - we don't want spaces or other odd characters !!
        m_multiType = HSStringUtil.ensureValidType(multiType, m_multiType);

        // If we are a collection the multi-type cannot be blank or native - set it to "Object" instead
        if (m_collection && ((m_multiType.length() == 0) || E_HSTypes.isNative(m_multiType))) {
            m_multiType = "Object";
        }

        // Finally set out native and immutable flags
        m_nativeMultiType    = E_HSTypes.isNative(m_multiType);
        m_immutableMultiType = E_HSTypes.isImmutable(m_multiType);
    }

    /**
     * Gets the property description.
     *
     * @return the property description
     */
    public String getDescription() {
        return m_description;
    }

    /**
     * Sets the property description.
     *
     * @param description the property description
     */
    public void setDescription(String description) {
        // Description shouldn't start with a capital
        m_description = HSStringUtil.ensureFirstLetterCase(description, false);

        // Description shouldn't end with a full stop
        if (m_description.endsWith(".")) {
            m_description = m_description.substring(0, (m_description.length() - 1)).trim();
        }
    }

    /**
     * Gets the variable name.
     *
     * @return the variable name
     */
    public String getVariableName() {
        return m_variableName;
    }

    /**
     * Gets the variable name (for use in generated, non-static, non-declaration code).
     *
     * @return the variable name (for use in generated, non-static, non-declaration code)
     */
    public String getCodeVariableName() {
        if (m_variableName.equals(m_name)) {
            // We don't have a prefix - resort to the horrible "this" convention
            return "this." + m_variableName;
        }

        return m_variableName;
    }

    /**
     * Sets the variable name.
     *
     * @param variableName the variable name
     */
    public void setVariableName(String variableName) {
        // Before we start - we don't want spaces or other odd characters !!
        m_variableName = HSStringUtil.ensureValidIdentifier(variableName, m_variableName);

        // Next ensure the variable name doesn't start with a capital
        m_variableName = HSStringUtil.ensureFirstLetterCase(m_variableName, false);
    }

    /**
     * Gets the singular name (singular version of the name).
     *
     * @return the singular name (singular version of the name)
     */
    public String getSingularName() {
        return m_singularName;
    }

    /**
     * Sets the singular name (singular version of the name).
     *
     * @param singularName the singular name (singular version of the name)
     */
    public void setSingularName(String singularName) {
        // Before we start - we don't want spaces or other odd characters !!
        m_singularName = HSStringUtil.ensureValidIdentifier(singularName, m_singularName);

        // Next ensure the singular name doesn't start with a capital
        m_singularName = HSStringUtil.ensureFirstLetterCase(m_singularName, false);
    }

    /**
     * Gets the property mode.
     *
     * @return the property mode
     */
    public int getMode() {
        return m_mode;
    }

    /**
     * Sets the property mode.
     *
     * @param mode the property mode
     */
    public void setMode(int mode) {
        if ((mode == READ_WRITE) || (mode == READ_ONLY) || (mode == WRITE_ONLY)) {
            m_mode = mode;
        }
    }

    /**
     * Gets whether the getter method is "is" for a boolean property
     * (otherwise it is "get").
     *
     * @return whether the getter methods are "is" for a boolean property
     */
    public boolean getIsGetterMethod() {
        return m_isGetterMethod;
    }

    /**
     * Sets whether the getter method is "is" for a boolean property
     * (otherwise it is "get").
     *
     * @param isGetterMethod whether the getter methods are "is" for a boolean property
     */
    public void setIsGetterMethod(boolean isGetterMethod) {
        m_isGetterMethod = isGetterMethod;
    }

    /**
     * Gets whether a multi-flag is set.
     *
     * @param multiFlag the multi-flag to test (one of the MULTI constants)
     * @return whether the multi-flag is set
     */
    public boolean getMultiFlag(int multiFlag) {
        if ((multiFlag < 0) || (multiFlag >= E_HSTypes.NUMBER_MULTI_FLAGS)) {
            throw new IllegalArgumentException("Multi-flag constant must be between 0 and " + (E_HSTypes.NUMBER_MULTI_FLAGS - 1));
        }

        return m_multiFlags[multiFlag];
    }

    /**
     * Sets whether a multi-flag is set.
     *
     * @param multiFlag the multi-flag to test (one of the MULTI constants)
     * @param set whether the multi-flag is to be set
     */
    public void setMultiFlag(int multiFlag, boolean set) {
        if ((multiFlag < 0) || (multiFlag >= E_HSTypes.NUMBER_MULTI_FLAGS)) {
            throw new IllegalArgumentException("Multi-flag constant must be between 0 and " + (E_HSTypes.NUMBER_MULTI_FLAGS - 1));
        }

        m_multiFlags[multiFlag] = set;
    }

    /**
     * Gets the capitalised name (with a capital at the start).
     *
     * @return the capitalised name (with a capital at the start)
     */
    public String getCapitalisedName() {
        return m_capitalisedName;
    }

    /**
     * Gets whether the property is a native type.
     *
     * @return whether the property is a native type
     */
    public boolean isNativeType() {
        return m_nativeType;
    }

    /**
     * Gets whether the property's multi-type is a native type.
     *
     * @return whether the property's multi-type is a native type
     */
    public boolean isNativeMultiType() {
        return m_nativeMultiType;
    }

    /**
     * Gets whether the property is an immutable type.
     *
     * @return whether the property is an immutable type
     */
    public boolean isImmutableType() {
        return m_immutableType;
    }

    /**
     * Gets whether the property's multi-type is an immutable type.
     *
     * @return whether the property's multi-type is an immutable type
     */
    public boolean isImmutableMultiType() {
        return m_immutableMultiType;
    }

    /**
     * Gets whether the property is a multi-valued property.
     *
     * @return whether the property is a multi-valued property
     */
    public boolean isMultiValue() {
        return m_multiValue;
    }

    /**
     * Gets whether the property is an array.
     *
     * @return whether the property is an array
     */
    public boolean isArray() {
        return m_array;
    }

    /**
     * Gets whether the property is a collection.
     *
     * @return whether the property is a collection
     */
    public boolean isCollection() {
        return m_collection;
    }

    /**
     * Gets whether the property is a list.
     *
     * @return whether the property is a list
     */
    public boolean isList() {
        return m_list;
    }

    /**
     * Gets whether the property is a set.
     *
     * @return whether the property is a set
     */
    public boolean isSet() {
        return m_set;
    }

    /**
     * Gets whether the property is a vector.
     *
     * @return whether the property is a vector
     */
    public boolean isVector() {
        return m_vector;
    }

    /**
     * Gets the caret start position for this property.
     *
     * @return the caret start position for this property
     */
    public int getCaretStartPosition() {
        return m_caretStartPosition;
    }

    /**
     * Sets the caret start position for this property.
     *
     * @param caretStartPosition the caret start position for this property
     */
    public void setCaretStartPosition(int caretStartPosition) {
        m_caretStartPosition = caretStartPosition;
    }

    /**
     * Gets the caret end position for this property.
     *
     * @return the caret end position for this property
     */
    public int getCaretEndPosition() {
        return m_caretEndPosition;
    }

    /**
     * Sets the caret end position for this property.
     *
     * @param caretEndPosition the caret end position for this property
     */
    public void setCaretEndPosition(int caretEndPosition) {
        m_caretEndPosition = caretEndPosition;
    }

    /**
     * Returns the property name as its string (for display in lists).
     *
     * @return the property name as its string (for display in lists)
     */
    public String toString() {
        return m_name;
    }

    /**
     * Returns whether a multi-flag is valid for this property.
     *
     * @param multiFlag the multi-flag to return the validity for
     * @return whether the multi-flag is valid for this property
     */
    public boolean isMultiValid(int multiFlag) {
        if ((multiFlag < 0) || (multiFlag >= E_HSTypes.NUMBER_MULTI_FLAGS)) {
            throw new IllegalArgumentException("Multi-flag constant must be between 0 and " + (E_HSTypes.NUMBER_MULTI_FLAGS - 1));
        }

        if (!m_multiValue) {
            // Not a multi value
            return false;
        }

        if (E_HSTypes.isReadMultiFlag(multiFlag) && !isReadAllowed()) {
            // Reads not allowed on this property
            return false;
        }

        if (E_HSTypes.isWriteMultiFlag(multiFlag) && !isWriteAllowed()) {
            // Writes not allowed on this property
            return false;
        }

        // In essence this multi-flag is switched on - is it actually valid ?
        // We are either an array, or we are a collection (or derivative)
        // so at least one of the following rules should fire. Note that
        // the ordering of test for the collection types is important
        // (the sub-types must be tested before the general collection)
        if (m_array) {
            if (m_nativeMultiType) {
                return E_HSTypes.isValidNativeArray(multiFlag);
            }
            else {
                return E_HSTypes.isValidObjectArray(multiFlag);
            }
        }

        if (m_vector) {
            return E_HSTypes.isValidVector(multiFlag);
        }

        if (m_set) {
            return E_HSTypes.isValidSet(multiFlag);
        }

        if (m_list) {
            return E_HSTypes.isValidList(multiFlag);
        }

        if (m_collection) {
            return E_HSTypes.isValidCollection(multiFlag);
        }

        // Default to false - we should never get here !!
        return false;
    }

    /**
     * Gets whether this property allows read.
     *
     * @return whether this property allows read
     */
    public boolean isReadAllowed() {
        return m_mode != WRITE_ONLY;
    }

    /**
     * Gets whether this property allows write.
     *
     * @return whether this property allows write
     */
    public boolean isWriteAllowed() {
        return m_mode != READ_ONLY;
    }

    /**
     * Gets a clone of this property.
     *
     * @return a clone of this property (or null if clone is not supported - should never happen as we implement Cloneable)
     */
    public Object clone() {
        try {
            HSBeanProperty clone = (HSBeanProperty) super.clone();

            // Just need to copy the array over manually (everything else is immutable)
            if (m_multiFlags != null) {
                clone.m_multiFlags = new boolean[m_multiFlags.length];

                for (int i = 0; i < m_multiFlags.length; i++) {
                    clone.m_multiFlags[i] = m_multiFlags[i];
                }
            }

            return clone;
        }
        catch (CloneNotSupportedException cnse) {
            return null;
        }
    }

    /**
     * Copies another property into this property.
     *
     * @param property the other property (HSBeanProperty) to copy into this property
     */
    public void copy(HSBeanProperty property) {
        m_name           = property.m_name;
        m_type           = property.m_type;
        m_multiType      = property.m_multiType;
        m_description    = property.m_description;
        m_variableName   = property.m_variableName;
        m_singularName   = property.m_singularName;
        m_mode           = property.m_mode;
        m_isGetterMethod = property.m_isGetterMethod;
        m_multiFlags     = property.m_multiFlags;

        if (property.m_multiFlags != null) {
            m_multiFlags = new boolean[property.m_multiFlags.length];

            for (int i = 0; i < property.m_multiFlags.length; i++) {
                m_multiFlags[i] = property.m_multiFlags[i];
            }
        }

        m_capitalisedName    = property.m_capitalisedName;
        m_nativeType         = property.m_nativeType;
        m_nativeMultiType    = property.m_nativeMultiType;
        m_immutableType      = property.m_immutableType;
        m_immutableMultiType = property.m_immutableMultiType;
        m_multiValue         = property.m_multiValue;
        m_array              = property.m_array;
        m_collection         = property.m_collection;
        m_list               = property.m_list;
        m_set                = property.m_set;
        m_vector             = property.m_vector;
        m_caretStartPosition = property.m_caretStartPosition;
        m_caretEndPosition   = property.m_caretEndPosition;
    }
}
