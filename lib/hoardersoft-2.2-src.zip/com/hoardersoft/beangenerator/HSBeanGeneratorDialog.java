package com.hoardersoft.beangenerator;

import com.hoardersoft.menu.HSMenu;
import com.hoardersoft.statusbar.HSStatusBar;
import com.hoardersoft.toolbar.HSToolbar;
import com.hoardersoft.util.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Class holding the main bean generator dialog.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSBeanGeneratorDialog extends JFrame {
    private static final int SOURCE_PANE  = 0;
    private static final int UTILITY_PANE = 1;

    // GUI members
    private JPanel m_toolbarPanel                 = new JPanel(new BorderLayout());
    private JPanel m_classNamePanel               = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 2));
    private JLabel m_classNameLabel               = new JLabel("Class:");
    private HSTextField m_classNameTextField      = new HSTextField();
    private JPanel m_topPanel                     = new JPanel(new BorderLayout());
    private JList m_propertyList                  = new JList();
    private JScrollPane m_propertyListPanel       = HSBeanUtil.createScrollPane(m_propertyList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    private JTabbedPane m_sourceUtilityTabbedPane = new JTabbedPane(JTabbedPane.TOP);
    private JTextArea m_sourceTextArea            = new JTextArea();
    private JScrollPane m_sourcePanel             = HSBeanUtil.createScrollPane(m_sourceTextArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    private JTextArea m_utilityTextArea           = new JTextArea();
    private JScrollPane m_utilityPanel            = HSBeanUtil.createScrollPane(m_utilityTextArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    private JSplitPane m_splitPane                = HSBeanUtil.createSplitPane(JSplitPane.VERTICAL_SPLIT, m_topPanel, m_sourceUtilityTabbedPane);
    private HSStatusBar m_statusBar               = new HSStatusBar();

    // Non-GUI members
    private HSBeanClass m_class                = new HSBeanClass();
    private HSBeanOptions m_options            = new HSBeanOptions();
    private HSBeanProperty m_lastPropertyAdded = null;

    /**
     * Class constructor.
     */
    public HSBeanGeneratorDialog() {
        super();

        // Set the icon
        setIconImage(HSIconUtil.loadImage("HoarderSoft.gif").getImage());

        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            throw new Error("Error initialising GUI - HSBeanGeneratorDialog");
        }

        // Set the initial size
        setSize(460, 600);

        // Set up the menu bar
        JMenuBar menubar = new JMenuBar();
        HSMenu fileMenu  = new HSMenu("File", m_statusBar);
        HSMenu editMenu  = new HSMenu("Edit", m_statusBar);
        HSMenu helpMenu  = new HSMenu("Help", m_statusBar);

        fileMenu.add(m_newAction);
        fileMenu.addSeparator();
        fileMenu.add(m_exitAction);
        editMenu.add(m_editAction);
        editMenu.add(m_deleteAction);
        editMenu.add(m_moveUpAction);
        editMenu.add(m_moveDownAction);
        editMenu.addSeparator();
        editMenu.addToggle(m_constructorAction);
        editMenu.addToggle(m_equalsAction);
        editMenu.addToggle(m_cloneAction);
        editMenu.addToggle(m_hashCodeAction);
        editMenu.addToggle(m_copyAction);
        editMenu.addToggle(m_debugAction);
        editMenu.addSeparator();
        editMenu.add(m_copyToClipboardAction);
        editMenu.addSeparator();
        editMenu.add(m_optionsAction);
        helpMenu.add(m_aboutAction);
        menubar.add(fileMenu);
        menubar.add(editMenu);
        menubar.add(helpMenu);
        setJMenuBar(menubar);

        // Set up the toolbar
        HSToolbar toolbar = new HSToolbar(m_statusBar);

        toolbar.add(m_newAction);
        toolbar.addDivider();
        toolbar.add(m_editAction);
        toolbar.add(m_deleteAction);
        toolbar.add(m_moveUpAction);
        toolbar.add(m_moveDownAction);
        toolbar.addDivider();
        toolbar.addToggle(m_constructorAction);
        toolbar.addToggle(m_equalsAction);
        toolbar.addToggle(m_cloneAction);
        toolbar.addToggle(m_hashCodeAction);
        toolbar.addToggle(m_copyAction);
        toolbar.addToggle(m_debugAction);
        toolbar.addDivider();
        toolbar.add(m_copyToClipboardAction);
        m_toolbarPanel.add(toolbar, BorderLayout.CENTER);

        // Add a close window listener
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                HSBeanGeneratorDialog.this.windowClosing();
            }
        });

        // Update our internal prefences
        m_options.updateFromPropertiesFile();

        // Update the GUI
        updateGUI();
    }

    /**
     * Show the dialog.
     */
    public void showDialog() {
        setVisible(true);
    }

    /**
     * Adds a property.
     *
     * @param property the property to add
     */
    public void addProperty(HSBeanProperty property) {
        m_class.addProperties(property);
        updateGUI();
    }

    /**
     * Updates the GUI.
     */
    private void updateGUI() {
        // Update the class name
        m_classNameTextField.setText(m_class.getClassName());

        // Update the list of properties
        m_propertyList.setListData(m_class.getPropertiesAsArray());

        // Update source code
        updateSourceCode();

        // Update the menu items
        updateMenuItems();

        // Update the options
        updateOptions();
    }

    /**
     * Updates the source code.
     */
    private void updateSourceCode() {
        StringBuffer buffer = new StringBuffer();

        // First get the class start code
        buffer.append(HSBeanCodeGenerator.getClassStartCode(m_class, m_options));

        // Next get our declarations
        for (Iterator iter = m_class.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty property = (HSBeanProperty) iter.next();

            buffer.append(HSBeanCodeGenerator.getDeclarationCode(property, m_options));
        }

        buffer.append(m_options.getIndentString() + "\n");

        // Next get our constructor
        if (m_options.isConstructorMethod()) {
            buffer.append(HSBeanCodeGenerator.getConstructorCode(m_class, m_options));
        }

        // Next get our accessors
        for (Iterator iter = m_class.getPropertiesIterator(); iter.hasNext(); ) {
            HSBeanProperty property = (HSBeanProperty) iter.next();

            // Set the start caret position
            property.setCaretStartPosition(buffer.length());

            // Append on the accessor code
            buffer.append(HSBeanCodeGenerator.getAccessorCode(property, m_options));

            // Set the end caret position
            property.setCaretEndPosition(buffer.length());
        }

        // Next get our equals, clone, hashcode, copy and debug methods
        if (m_options.isEqualsMethod()) {
            buffer.append(HSBeanCodeGenerator.getEqualsCode(m_class, m_options));
        }

        if (m_options.isCloneMethod()) {
            buffer.append(HSBeanCodeGenerator.getCloneCode(m_class, m_options));
        }

        if (m_options.isHashCodeMethod()) {
            buffer.append(HSBeanCodeGenerator.getHashcodeCode(m_class, m_options));
        }

        if (m_options.isCopyMethod()) {
            buffer.append(HSBeanCodeGenerator.getCopyCode(m_class, m_options));
        }

        if (m_options.isDebugMethod()) {
            buffer.append(HSBeanCodeGenerator.getDebugCode(m_class, m_options));
        }

        // Add the utility methods
        buffer.append(HSBeanCodeGenerator.getStaticUtilityCode(m_class, m_options));

        // Finally get the class end code
        buffer.append(HSBeanCodeGenerator.getClassEndCode(m_class));

        // Set the source text
        m_sourceTextArea.setText(buffer.toString());

        // Now the utility code
        m_utilityTextArea.setText(HSBeanCodeGenerator.getUtilityClassesCode(m_class, m_options));
    }

    /**
     * Updates the state of the menu items.
     */
    private void updateMenuItems() {
        int nSelected = m_propertyList.getSelectedIndices().length;

        if (nSelected > 1) {
            m_editAction.setEnabled(false);
            m_deleteAction.setEnabled(true);
            m_moveUpAction.setEnabled(false);
            m_moveDownAction.setEnabled(false);
        }
        else {
            int selected    = getSelectedPropertyIndex();
            int nProperties = m_class.getPropertiesCount();

            m_editAction.setEnabled((selected >= 0) && (selected < nProperties));
            m_deleteAction.setEnabled((selected >= 0) && (selected < nProperties));
            m_moveUpAction.setEnabled((selected > 0) && (selected < nProperties));
            m_moveDownAction.setEnabled((selected >= 0) && (selected < (nProperties - 1)));
        }
    }

    /**
     * Updates the state of the options.
     */
    private void updateOptions() {
        HSBeanUtil.setRelatedButtons(m_constructorAction, m_options.isConstructorMethod());
        HSBeanUtil.setRelatedButtons(m_equalsAction, m_options.isEqualsMethod());
        HSBeanUtil.setRelatedButtons(m_cloneAction, m_options.isCloneMethod());
        HSBeanUtil.setRelatedButtons(m_hashCodeAction, m_options.isHashCodeMethod());
        HSBeanUtil.setRelatedButtons(m_copyAction, m_options.isCopyMethod());
        HSBeanUtil.setRelatedButtons(m_debugAction, m_options.isDebugMethod());
    }

    /**
     * Called when the new button is pressed.
     */
    private void newProperty() {
        HSBeanProperty newProperty = null;

        if (m_lastPropertyAdded != null) {
            // Clone our last added property and rename
            newProperty = (HSBeanProperty) m_lastPropertyAdded.clone();

            newProperty.setName(getNewPropertyName());
        }
        else {
            // Just create a new property of integer type
            newProperty = new HSBeanProperty(getNewPropertyName(), "int", m_options);
        }

        HSBeanPropertyEditDialog editDialog = new HSBeanPropertyEditDialog(this, newProperty);

        if (editDialog.showDialog()) {
            addProperty(newProperty);

            // Stash our most recently added property
            m_lastPropertyAdded = (HSBeanProperty) newProperty.clone();

            // Select for user convienience
            m_propertyList.setSelectedIndex(m_class.getPropertiesCount() - 1);
            scrollPropertyList();
        }
    }

    /**
     * Called when the delete button is pressed.
     */
    private void deleteProperty() {
        int firstSelected = getSelectedPropertyIndex();
        int[] selected    = m_propertyList.getSelectedIndices();
        int nProperties   = m_class.getPropertiesCount();
        ArrayList remove  = new ArrayList();

        for (int i = 0; i < selected.length; i++) {
            if ((selected[i] >= 0) && (selected[i] < nProperties)) {
                remove.add(m_class.getProperties(selected[i]));
            }
        }

        for (Iterator iter = remove.iterator(); iter.hasNext(); ) {
            m_class.removeProperties((HSBeanProperty) iter.next());
        }

        updateGUI();

        // Re-select for user convienience
        if (firstSelected >= m_class.getPropertiesCount()) {
            firstSelected = m_class.getPropertiesCount() - 1;
        }

        m_propertyList.setSelectedIndex(firstSelected);
        scrollPropertyList();
    }

    /**
     * Called when the move up button is pressed.
     */
    private void movePropertyUp() {
        int selected = getSelectedPropertyIndex();

        if (selected > 0) {
            HSBeanProperty property = getSelectedProperty();

            m_class.removeProperties(selected--);
            m_class.addProperties(selected, property);
            updateGUI();

            // Re-select for user convienience
            m_propertyList.setSelectedIndex(selected);
        }
    }

    /**
     * Called when the move down button is pressed.
     */
    private void movePropertyDown() {
        int selected = getSelectedPropertyIndex();
        int nEnums   = m_class.getPropertiesCount();

        if ((selected >= 0) && (selected < (nEnums - 1))) {
            HSBeanProperty property = getSelectedProperty();

            m_class.removeProperties(selected++);
            m_class.addProperties(selected, property);
            updateGUI();

            // Re-select for user convienience
            m_propertyList.setSelectedIndex(selected);
        }
    }

    /**
     * Called when the edit button is pressed.
     */
    private void editProperty() {
        int selected = getSelectedPropertyIndex();

        if (selected >= 0) {
            HSBeanPropertyEditDialog editDialog = new HSBeanPropertyEditDialog(this, getSelectedProperty());

            if (editDialog.showDialog()) {
                updateGUI();

                // Re-select for user convienience
                m_propertyList.setSelectedIndex(selected);
                scrollPropertyList();
            }
        }
    }

    /**
     * Gets a new property name.
     *
     * @return a new property name
     */
    private String getNewPropertyName() {
        String name   = "newProperty";
        boolean found = true;
        int index     = 1;

        while (found) {
            found = false;

            for (Iterator iter = m_class.getPropertiesIterator(); iter.hasNext() && !found; ) {
                HSBeanProperty property = (HSBeanProperty) iter.next();

                if (property.getName().equalsIgnoreCase(name)) {
                    found = true;
                }
            }

            if (found) {
                index++;

                name = "newProperty" + index;
            }
        }

        return name;
    }

    /**
     * Returns the currently selected property.
     *
     * @return the currently selected property (null if none currently selected)
     */
    private HSBeanProperty getSelectedProperty() {
        int selected = getSelectedPropertyIndex();

        if (selected >= 0) {
            return m_class.getProperties(selected);
        }

        return null;
    }

    /**
     * Returns the currently selected property index.
     *
     * @return the currently selected property index
     */
    private int getSelectedPropertyIndex() {
        // Crap Swing component can return current index out of bounds !!
        int selected = m_propertyList.getSelectedIndex();

        if ((selected >= 0) && (selected < m_class.getPropertiesCount())) {
            return selected;
        }

        return -1;
    }

    /**
     * Scrolls the source pane to the currently selected property.
     */
    private void scrollSource() {
        // Go to the relevant line number
        HSBeanProperty property = getSelectedProperty();

        if (property != null) {
            m_sourceUtilityTabbedPane.setSelectedIndex(SOURCE_PANE);
            m_sourceTextArea.select(property.getCaretStartPosition(), property.getCaretStartPosition());
        }
    }

    /**
     * Scrolls the property list to the currently selected property.
     */
    private void scrollPropertyList() {
        int selectedIndex = getSelectedPropertyIndex();

        m_propertyList.ensureIndexIsVisible(selectedIndex);
    }

    /**
     * Called when the class name is edited.
     */
    private void updateClassName() {
        // Ensure the class name is a valid identifier
        String className = m_classNameTextField.getText().trim();

        m_class.setClassName(HSStringUtil.ensureValidIdentifier(className, m_class.getClassName()));
        updateGUI();
    }

    /**
     * Called when the program is closing.
     */
    private void windowClosing() {
        // Update our preferences and write them out
        m_options.updatePropertiesFile();

        // We can now exit safely
        System.exit(0);
    }

    /**
     * Called to show the options dialog.
     */
    private void showOptionsDialog() {
        HSBeanOptionsDialog optionsDialog = new HSBeanOptionsDialog(this);

        if (optionsDialog.showDialog(m_options)) {
            updateGUI();
        }
    }

    /**
     * Called to show the about dialog.
     */
    private void showAboutDialog() {
        HSAboutDialog aboutDialog = new HSAboutDialog(this, "HSBeanGenerator");

        aboutDialog.showDialog();
    }

    /**
     * Called to copy the current text to the clipboard.
     */
    private void copyToClipboard() {
        // Now transfer this data to the system clipboard
        Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection data;

        if (m_sourceUtilityTabbedPane.getSelectedIndex() == SOURCE_PANE) {
            data = new StringSelection(m_sourceTextArea.getText());
        }
        else if (m_sourceUtilityTabbedPane.getSelectedIndex() == UTILITY_PANE) {
            data = new StringSelection(m_utilityTextArea.getText());
        }
        else {
            // Should never happen
            data = new StringSelection("");
        }

        clip.setContents(data, data);
    }

    // ---------------------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------------------
    private Action m_newAction = new HSAbstractAction("New", "Creates a new property", "New.png") {
        public void actionPerformed(ActionEvent e) {
            newProperty();
        }
    };
    private Action m_editAction = new HSAbstractAction("Edit", "Edits a property", "Edit.png") {
        public void actionPerformed(ActionEvent e) {
            editProperty();
        }
    };
    private Action m_deleteAction = new HSAbstractAction("Delete", "Deletes a property", "Delete.png") {
        public void actionPerformed(ActionEvent e) {
            deleteProperty();
        }
    };
    private Action m_moveUpAction = new HSAbstractAction("Move Up", "Moves a property up", "MoveUp.png") {
        public void actionPerformed(ActionEvent e) {
            movePropertyUp();
        }
    };
    private Action m_moveDownAction = new HSAbstractAction("Move Down", "Moves a property down", "MoveDown.png") {
        public void actionPerformed(ActionEvent e) {
            movePropertyDown();
        }
    };
    private Action m_exitAction = new HSAbstractAction("Exit", "Exits the program") {
        public void actionPerformed(ActionEvent e) {
            HSBeanGeneratorDialog.this.windowClosing();
        }
    };
    private Action m_constructorAction = new HSAbstractAction("Constructor", "Toggles the constructor", "Constructor.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setConstructorMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_equalsAction = new HSAbstractAction("Equals", "Toggles the equals method", "Equals.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setEqualsMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_cloneAction = new HSAbstractAction("Clone", "Toggles the clone method", "Clone.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setCloneMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_hashCodeAction = new HSAbstractAction("Hashcode", "Toggles the hashcode method", "HashCode.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setHashCodeMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_copyAction = new HSAbstractAction("Copy", "Toggles the copy method", "Copy.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setCopyMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_debugAction = new HSAbstractAction("Debug", "Toggles the debug (toString) method", "Debug.png") {
        public void actionPerformed(ActionEvent e) {
            m_options.setDebugMethod(((AbstractButton) e.getSource()).isSelected());
            updateGUI();
        }
    };
    private Action m_optionsAction = new HSAbstractAction("Options...", "Raises the options dialog") {
        public void actionPerformed(ActionEvent e) {
            showOptionsDialog();
        }
    };
    private Action m_aboutAction = new HSAbstractAction("About...", "Raises the about dialog") {
        public void actionPerformed(ActionEvent e) {
            showAboutDialog();
        }
    };
    private Action m_copyToClipboardAction = new HSAbstractAction("Copy to Clipboard", "Copies the current source to the system clipboard", "CopyToClipboard.png") {
        public void actionPerformed(ActionEvent e) {
            copyToClipboard();
        }
    };

    // ---------------------------------------------------------------------------------
    // All code beneath here is GUI callback code
    // ---------------------------------------------------------------------------------
    private void m_propertyList_mouseClicked(MouseEvent e) {
        scrollSource();

        if (e.getClickCount() > 1) {
            editProperty();
        }
    }

    private void m_propertyList_valueChanged() {
        updateMenuItems();
        scrollSource();
    }

    private void m_classNameTextField_focusLost() {
        updateClassName();
    }

    private void m_classNameTextField_actionPerformed() {
        updateClassName();
    }

    private void jbInit() {
        getContentPane().add(m_toolbarPanel, BorderLayout.NORTH);
        getContentPane().add(m_splitPane, BorderLayout.CENTER);
        getContentPane().add(m_statusBar, BorderLayout.SOUTH);
        m_toolbarPanel.add(m_classNamePanel, BorderLayout.EAST);
        m_classNamePanel.add(m_classNameLabel, null);
        m_classNamePanel.add(Box.createHorizontalStrut(5), null);
        m_classNamePanel.add(m_classNameTextField, null);
        m_classNameTextField.setPreferredSize(new Dimension(120, 21));
        m_classNameTextField.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                m_classNameTextField_focusLost();
            }
        });
        m_classNameTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                m_classNameTextField_actionPerformed();
            }
        });
        m_splitPane.setDividerLocation(100);
        m_topPanel.add(m_propertyListPanel, BorderLayout.CENTER);
        m_sourceUtilityTabbedPane.add(m_sourcePanel, "Source");
        m_sourceUtilityTabbedPane.add(m_utilityPanel, "Utility");
        m_propertyList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                m_propertyList_mouseClicked(e);
            }
        });
        m_propertyList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                m_propertyList_valueChanged();
            }
        });
        m_sourceTextArea.setFont(new Font("DialogInput", 0, 11));
        m_sourceTextArea.setEditable(false);
        m_sourceTextArea.setSelectionColor(new Color(10, 36, 106));
        m_utilityTextArea.setFont(new Font("DialogInput", 0, 11));
        m_utilityTextArea.setEditable(false);
        m_utilityTextArea.setSelectionColor(new Color(10, 36, 106));
        setResizable(true);
        setTitle("Bean Generator");
    }
}
