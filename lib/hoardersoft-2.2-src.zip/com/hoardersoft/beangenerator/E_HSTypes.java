package com.hoardersoft.beangenerator;

/**
 * Class to hold type information.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class E_HSTypes {
    static public final int MULTI_GET             = 0;
    static public final int MULTI_GET_INDEX       = 1;
    static public final int MULTI_GET_ITERATOR    = 2;
    static public final int MULTI_GET_ENUMERATION = 3;
    static public final int MULTI_GET_COUNT       = 4;
    static public final int MULTI_GET_AS_ARRAY    = 5;
    static public final int MULTI_INDEX_OF        = 6;
    static public final int MULTI_ACTUAL_INDEX_OF = 7;
    static public final int MULTI_SET             = 8;
    static public final int MULTI_SET_INDEX       = 9;
    static public final int MULTI_ADD             = 10;
    static public final int MULTI_ADD_INDEX       = 11;
    static public final int MULTI_REMOVE          = 12;
    static public final int MULTI_REMOVE_INDEX    = 13;
    static public final int MULTI_CLEAR           = 14;
    static public final int NUMBER_MULTI_FLAGS    = 15;

    // Native types are boolean, byte, char, double, float, int, long, short
    static private final String[] NATIVES = new String[] {
        "boolean", "byte", "char", "double", "float", "int", "long", "short"
    };

    // Native hash ints are byte, char, short, int
    static private final String[] NATIVE_HASH_INTS = new String[]{ "byte", "char", "short", "int" };

    // Immutable types are boolean, byte, char, double, float, int, long, short, String, Boolean, Byte, Character, Double, Float, Int, Long, Short, BigInteger, BigDecimal
    static private final String[] IMMUTABLES = new String[] {
        "boolean", "byte", "char", "double", "float", "int", "long", "short", "String", "Boolean", "Byte", "Character", "Double", "Float", "Integer", "Long", "Short", "BigInteger", "BigDecimal"
    };

    // Collections are any objects or interfaces that implement Collection
    static private final String[] COLLECTIONS = new String[] {
        "ArrayList", "Collection", "HashSet", "LinkedList", "List", "Set", "SortedSet", "TreeSet", "Vector"
    };

    // Collection classes are any classes that implement Collection
    static private final String[] COLLECTION_CLASSES = new String[]{ "ArrayList", "HashSet", "LinkedList", "TreeSet", "Vector" };

    // Collection interfaces are any interfaces that are or extend Collection
    static private final String[] COLLECTION_INTERFACES = new String[]{ "Collection", "List", "Set", "SortedSet" };

    // Lists are any objects that implement List
    static private final String[] LISTS = new String[]{ "ArrayList", "LinkedList", "List", "Stack", "Vector" };

    // Sets are any objects that implement Set
    static private final String[] SETS = new String[]{ "HashSet", "Set", "SortedSet", "TreeSet" };

    // Vectors are any objects that are, or extend, the Vector class
    static private final String[] VECTORS = new String[]{ "Stack", "Vector" };

    // Operations allowed on native arrays
    static private final int[] NATIVE_ARRAY_MULTI_FLAGS = new int[]{ MULTI_GET, MULTI_GET_INDEX, MULTI_GET_COUNT, MULTI_SET, MULTI_SET_INDEX };

    // Operations allowed on object arrays (same as native arrays plus index of operations)
    static private final int[] OBJECT_ARRAY_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_INDEX, MULTI_GET_COUNT, MULTI_INDEX_OF, MULTI_ACTUAL_INDEX_OF, MULTI_SET, MULTI_SET_INDEX
    };

    // Operations allowed on collections
    static private final int[] COLLECTION_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_ITERATOR, MULTI_GET_COUNT, MULTI_GET_AS_ARRAY, MULTI_SET, MULTI_ADD, MULTI_REMOVE, MULTI_CLEAR
    };

    // Operations allowed on lists (same as collections plus index operations)
    static private final int[] LIST_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_INDEX, MULTI_GET_ITERATOR, MULTI_GET_COUNT, MULTI_GET_AS_ARRAY, MULTI_INDEX_OF, MULTI_ACTUAL_INDEX_OF, MULTI_SET, MULTI_SET_INDEX, MULTI_ADD, MULTI_ADD_INDEX, MULTI_REMOVE, MULTI_REMOVE_INDEX, MULTI_CLEAR
    };

    // Operations allowed on sets (same as collections)
    static private final int[] SET_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_ITERATOR, MULTI_GET_COUNT, MULTI_GET_AS_ARRAY, MULTI_SET, MULTI_ADD, MULTI_REMOVE, MULTI_CLEAR
    };

    // Operations allowed on vectors (same as lists plus enumeration operation)
    static private final int[] VECTOR_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_INDEX, MULTI_GET_ITERATOR, MULTI_GET_ENUMERATION, MULTI_GET_COUNT, MULTI_GET_AS_ARRAY, MULTI_INDEX_OF, MULTI_ACTUAL_INDEX_OF, MULTI_SET, MULTI_SET_INDEX, MULTI_ADD, MULTI_ADD_INDEX, MULTI_REMOVE, MULTI_REMOVE_INDEX, MULTI_CLEAR
    };

    // Operations allowed on read multi-values
    static private final int[] READ_MULTI_FLAGS = new int[] {
        MULTI_GET, MULTI_GET_INDEX, MULTI_GET_ITERATOR, MULTI_GET_ENUMERATION, MULTI_GET_COUNT, MULTI_GET_AS_ARRAY, MULTI_INDEX_OF, MULTI_ACTUAL_INDEX_OF
    };

    // Operations allowed on write multi-values
    static private final int[] WRITE_MULTI_FLAGS = new int[] {
        MULTI_SET, MULTI_SET_INDEX, MULTI_ADD, MULTI_ADD_INDEX, MULTI_REMOVE, MULTI_REMOVE_INDEX, MULTI_CLEAR
    };

    /**
     * Returns whether a type is a generic object.
     *
     * @param type the type
     * @return whether the type is a generic object
     */
    static public boolean isGenericObject(String type) {
        return type.equals("Object");
    }

    /**
     * Returns whether a type is native.
     *
     * @param type the type
     * @return whether the type is native
     */
    static public boolean isNative(String type) {
        return contains(NATIVES, type);
    }

    /**
     * Returns whether a type is native hash int (converted to int for hashing).
     *
     * @param type the type
     * @return whether the type is native hash int
     */
    static public boolean isNativeHashInt(String type) {
        return contains(NATIVE_HASH_INTS, type);
    }

    /**
     * Returns whether a type is native boolean.
     *
     * @param type the type
     * @return whether the type is native boolean
     */
    static public boolean isNativeBoolean(String type) {
        return type.equals("boolean");
    }

    /**
     * Returns whether a type is native int.
     *
     * @param type the type
     * @return whether the type is native int
     */
    static public boolean isNativeInt(String type) {
        return type.equals("int");
    }

    /**
     * Returns whether a type is native long.
     *
     * @param type the type
     * @return whether the type is native long
     */
    static public boolean isNativeLong(String type) {
        return type.equals("long");
    }

    /**
     * Returns whether a type is native float.
     *
     * @param type the type
     * @return whether the type is native float
     */
    static public boolean isNativeFloat(String type) {
        return type.equals("float");
    }

    /**
     * Returns whether a type is native double.
     *
     * @param type the type
     * @return whether the type is native double
     */
    static public boolean isNativeDouble(String type) {
        return type.equals("double");
    }

    /**
     * Returns whether a type is immutable.
     *
     * @param type the type
     * @return whether the type is immutable
     */
    static public boolean isImmutable(String type) {
        return contains(IMMUTABLES, type);
    }

    /**
     * Returns whether a type is an array.
     *
     * @param type the type
     * @return whether the type is an array
     */
    static public boolean isArray(String type) {
        int typeLen = type.length();

        return (typeLen > 2) && (type.charAt(typeLen - 2) == '[') && (type.charAt(typeLen - 1) == ']');
    }

    /**
     * Returns the multi-value type for an array type.
     *
     * @param arrayType the array type
     * @return the multi-value type for an array type
     */
    static public String getArrayMultiType(String arrayType) {
        if (!isArray(arrayType)) {
            throw new Error("Non-array type passed to getArrayMultiType: " + arrayType);
        }

        return arrayType.substring(0, (arrayType.length() - 2));
    }

    /**
     * Returns whether a type is a collection.
     *
     * @param type the type
     * @return whether the type is a collection
     */
    static public boolean isCollection(String type) {
        return contains(COLLECTIONS, type);
    }

    /**
     * Returns whether a type is a collection class.
     *
     * @param type the type
     * @return whether the type is a collection class
     */
    static public boolean isCollectionClass(String type) {
        return contains(COLLECTION_CLASSES, type);
    }

    /**
     * Returns whether a type is a collection interface.
     *
     * @param type the type
     * @return whether the type is a collection interface
     */
    static public boolean isCollectionInterface(String type) {
        return contains(COLLECTION_INTERFACES, type);
    }

    /**
     * Returns whether a type is a list.
     *
     * @param type the type
     * @return whether the type is a list
     */
    static public boolean isList(String type) {
        return contains(LISTS, type);
    }

    /**
     * Returns whether a type is a set.
     *
     * @param type the type
     * @return whether the type is a set
     */
    static public boolean isSet(String type) {
        return contains(SETS, type);
    }

    /**
     * Returns whether a type is a vector.
     *
     * @param type the type
     * @return whether the type is a vector
     */
    static public boolean isVector(String type) {
        return contains(VECTORS, type);
    }

    /**
     * Returns whether a multi-flag is a read multi-flag.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a read multi-flag
     */
    static public boolean isReadMultiFlag(int multiFlag) {
        return contains(READ_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a write multi-flag.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a write multi-flag
     */
    static public boolean isWriteMultiFlag(int multiFlag) {
        return contains(WRITE_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid native array operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid native array operation
     */
    static public boolean isValidNativeArray(int multiFlag) {
        return contains(NATIVE_ARRAY_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid object array operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid object array operation
     */
    static public boolean isValidObjectArray(int multiFlag) {
        return contains(OBJECT_ARRAY_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid collection operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid collection operation
     */
    static public boolean isValidCollection(int multiFlag) {
        return contains(COLLECTION_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid list operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid list operation
     */
    static public boolean isValidList(int multiFlag) {
        return contains(LIST_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid set operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid set operation
     */
    static public boolean isValidSet(int multiFlag) {
        return contains(SET_MULTI_FLAGS, multiFlag);
    }

    /**
     * Returns whether a multi-flag is a valid vector operation.
     *
     * @param multiFlag the multi-flag
     * @return whether the multi-flag is a valid vector operation
     */
    static public boolean isValidVector(int multiFlag) {
        return contains(VECTOR_MULTI_FLAGS, multiFlag);
    }

    /**
     * Return whether a string array contains a given value or not.
     *
     * @param array the string array
     * @param value the string value to search for
     * @return whether the array contains the specified value
     */
    static public boolean contains(String[] array, String value) {
        if (array == null) {
            return false;
        }

        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(value)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return whether an integer array contains a given value or not.
     *
     * @param array the integer array
     * @param value the integer value to search for
     * @return whether the array contains the specified value
     */
    static public boolean contains(int[] array, int value) {
        if (array == null) {
            return false;
        }

        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                return true;
            }
        }

        return false;
    }
}
