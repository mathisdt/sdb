package com.hoardersoft.statusbar;

import javax.swing.*;

import java.awt.*;

/**
 * Class used for status bars.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSStatusBar extends JPanel implements HSStatusBarListener {
    private JLabel m_label;

    /**
     * Class constructor.
     */
    public HSStatusBar() {
        setLayout(new BorderLayout(0, 0));

        m_label = new JLabel("");

        add(Box.createHorizontalStrut(2), BorderLayout.WEST);
        add(m_label);
        add(Box.createHorizontalStrut(2), BorderLayout.EAST);
        setPreferredSize(new Dimension(-1, 22));
    }

    public void status(String status) {
        m_label.setText(status);
    }
}
