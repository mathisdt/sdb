package com.hoardersoft.colourselector;

import com.hoardersoft.util.HSBeanUtil;

import info.clearthought.layout.TableLayout;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Test class for HSColourSelector.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
public class HSColourSelectorTest {
    private HSColourSelectorWithLabel m_colourSelector = null;
    private final static double BORDER                 = 0.0;
    private final static int SPACE                     = 5;
    private final static double FILL                   = TableLayout.FILL;
    private final static double PREF                   = TableLayout.PREFERRED;
    private final static double[][] SIZES              = {
        { BORDER, PREF, FILL, BORDER }, { BORDER, PREF, PREF, BORDER }
    };

    /**
     * Class constructor.
     */
    public HSColourSelectorTest() {
        HSBeanUtil.setLookAndFeel();

        JFrame frame = new JFrame("HSColourSelectorTest");

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.out.println("Colour Selected: " + m_colourSelector.getColour());
                System.exit(0);
            }
        });

        //m_colourSelector = new HSColourSelectorWithLabel(new Color(255, 153, 204), "Select Colour", true);
        m_colourSelector = new HSColourSelectorWithLabel(new Color(255, 153, 204), "Select Colour", false);

        m_colourSelector.setLabelExpands(true);
        m_colourSelector.setLabelWidth(100);
        m_colourSelector.setNoColourEnabled(true);

        //m_colourSelector.setNoColourLabel("No Colour");
        //m_colourSelector.setMoreColoursLabel("Custom");
        //m_colourSelector.setBackground(Color.RED);
        //m_colourSelector.setEnabled(false);
        m_colourSelector.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Colour Changed: " + m_colourSelector.getColour());
            }
        });
        m_colourSelector.addCancelActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Colour Not Changed: " + m_colourSelector.getColour());
            }
        });

        TableLayout layout = new TableLayout(SIZES);

        layout.setHGap(SPACE);
        layout.setVGap(SPACE);

        JPanel panel = new JPanel(layout);

        panel.add(m_colourSelector, "1,1,2,1");

        // Just for comparison add an actual combo box
        Object[] items       = new String[]{ "Wibble", "Wobble", "Wabble" };
        JTextField textField = new JTextField("Test");
        JComboBox combo      = new JComboBox(items);

        textField.setToolTipText("This is a textfield");

        //textField.setEnabled(false);
        panel.add(textField, "1,2");
        panel.add(combo, "2,2");

        // Now add the panel and show the frame
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    /**
     * Main method.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new HSColourSelectorTest();
    }
}
