package com.hoardersoft.colourselector;

import com.hoardersoft.util.HSStringUtil;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import info.clearthought.layout.TableLayout;

/**
 * HoarderSoft colour selector bean. Basically just a pull down swatch
 * menu with 40 swatches (taken from Word) with a "More Colours" button
 * to bring up the full Java colour selector. Normally renders as a
 * combo box with a plain label for the disabled state. However can
 * also be set to just render as a label all the time.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public class HSColourSelector extends JPanel {
    private JComponent m_component         = null;
    private JComponent m_disabledComponent = null;
    private HSColourPanel m_colourPanel    = null;
    private JWindow m_window               = null;
    private ArrayList m_listenerList       = new ArrayList();
    private ArrayList m_cancelListenerList = new ArrayList();
    private Color m_colour                 = null;
    private boolean m_hexColourString      = true;
    private JPanel m_hiddenPanel           = new JPanel();
    private boolean m_asLabel              = false;

    // Color for label border (if shown as label)
    private static final Color LABEL_BORDER_COLOR = new Color(195, 195, 195);

    // Tablelayout constants
    private final static double FILL      = TableLayout.FILL;
    private final static double[][] SIZES = {
        { FILL }, { FILL }
    };

    // Window focus listener
    private FocusListener m_windowFocusListener = new FocusAdapter() {
        public void focusLost(FocusEvent e) {
            // We only want to catch "temporary" focus loss (otherwise
            // pressing tab will hide the window - not what we want!)
            if (e.isTemporary()) {
                // Hide the popup window
                hidePopup(true);
            }
        }
    };

    // Window key listener
    private KeyListener m_windowKeyListener = new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                // Escape pressed - hide the popup window
                hidePopup(true);
            }
            else if ((e.getKeyCode() == KeyEvent.VK_ENTER) || (e.getKeyCode() == KeyEvent.VK_SPACE)) {
                // Colour selected - hide the popup window (without calling the listeners - updateColour() will do this!)
                hidePopup(false);
                updateColour(m_colourPanel.getColour());
            }
            else if (e.getKeyCode() == KeyEvent.VK_UP) {
                m_colourPanel.colourUp();
            }
            else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                m_colourPanel.colourDown();
            }
            else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                m_colourPanel.colourLeft();
            }
            else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                m_colourPanel.colourRight();
            }
        }
    };

    // Hidden mouse listener
    private MouseListener m_hiddenMouseListener = new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
            e.consume();
            togglePopup();
        }

        public void mouseEntered(MouseEvent e) {
            e.consume();
        }

        public void mouseExited(MouseEvent e) {
            e.consume();
        }

        public void mousePressed(MouseEvent e) {
            e.consume();
        }

        public void mouseReleased(MouseEvent e) {
            e.consume();
        }
    };

    // Hidden key listener
    private KeyListener m_hiddenKeyListener = new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
            e.consume();

            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                togglePopup();
            }
        }

        public void keyReleased(KeyEvent e) {
            e.consume();
        }

        public void keyTyped(KeyEvent e) {
            e.consume();
        }
    };

    /**
     * Class constructor.
     */
    public HSColourSelector() {
        this(null, false);
    }

    /**
     * Class constructor that takes a "button" toggle.
     *
     * @param asLabel whether the colour selector renders as a label (otherwise rendered as a combo box)
     */
    public HSColourSelector(boolean asLabel) {
        this(null, asLabel);
    }

    /**
     * Class constructor that takes an initial colour.
     *
     * @param colour the initial colour (null for "no colour")
     */
    public HSColourSelector(Color colour) {
        this(colour, false);
    }

    /**
     * Class constructor that takes an initial colour and a "button" toggle.
     *
     * @param colour the initial colour (null for "no colour")
     * @param asLabel whether the colour selector renders as a label (otherwise rendered as a combo box)
     */
    public HSColourSelector(Color colour, boolean asLabel) {
        m_colour = colour;

        init(asLabel);
    }

    /**
     * Initialises the selector dialog.
     *
     * @param asLabel whether the colour selector renders as a label (otherwise rendered as a combo box)
     */
    private void init(boolean asLabel) {
        // Create the main component
        m_asLabel = asLabel;

        if (m_asLabel) {
            m_component = new JLabel();

            m_component.setOpaque(true);
            m_component.setBorder(BorderFactory.createLineBorder(LABEL_BORDER_COLOR));
        }
        else {
            // Set up the main component (the combo box)
            m_component = new JComboBox();

            m_component.setOpaque(false);
            
            // Set up the disabled component (a plain label)
            m_disabledComponent = new JLabel();
            
            m_disabledComponent.setOpaque(true);
            m_disabledComponent.setBorder(BorderFactory.createLineBorder(LABEL_BORDER_COLOR));
        }

        // Set opacity
        setOpaque(false);
        m_hiddenPanel.setOpaque(false);

        // Set up the GUI - note we overlay a hidden panel to grab mouse events!
        setLayout(new TableLayout(SIZES));
        setPreferredSize(new Dimension(37, 19));
        add(m_hiddenPanel, "0,0");
        add(m_component, "0,0");

        // Make our hidden panel grab all mouse events
        m_hiddenPanel.addMouseListener(m_hiddenMouseListener);

        // Override the key events
        m_component.addKeyListener(m_hiddenKeyListener);

        // Create the colour panel
        m_colourPanel = new HSColourPanel(m_colour, this);

        // Set the colour
        setColour(m_colour);
    }

    /**
     * Gets the selected colour.
     *
     * @return the selected colour (null for "no colour")
     */
    public Color getColour() {
        return m_colour;
    }

    /**
     * Sets the selected colour and updates any listeners.
     *
     * @param colour the colour to set the selected colour to (null for "no colour")
     */
    public void updateColour(Color colour) {
        Color oldColour = m_colour;

        setColour(colour);

        // Work out if the colour has actually changed so the right listeners are called
        boolean sameColour = ((m_colour == null) ? (oldColour == null) : m_colour.equals(oldColour));

        updateListeners(!sameColour);
        repaint();
    }

    /**
     * Sets the selected colour.
     *
     * @param colour the colour to set the selected colour to (null for "no colour")
     */
    public void setColour(Color colour) {
        m_colour = colour;

        m_colourPanel.setColour(m_colour);

        if (m_colour != null) {
            setComponentBackground(m_colour);

            if (m_hexColourString) {
                m_hiddenPanel.setToolTipText(HSStringUtil.getColourString(colour));
            }
            else {
                m_hiddenPanel.setToolTipText("RGB: " + colour.getRed() + "," + colour.getGreen() + "," + colour.getBlue());
            }
        }
        else {
            // Our component should look "transparent"
            // Setting opacity on combo-boxes doesn't work :(
            // So explicitly set colour to the background colour
            setComponentBackground(getBackground());

            // Also set the tooltip text appropriately
            m_hiddenPanel.setToolTipText(m_colourPanel.getNoColourLabel());
        }
    }

    public void setBackground(Color bg) {
        // We override this because if our component is "transparent"
        // then we'll need to change its background colour to match
        super.setBackground(bg);

        if ((m_component != null) && (m_colour == null)) {
            // Our component should look "transparent"
            // Setting opacity on combo-boxes doesn't work :(
            // So explicitly set colour to the background colour
            setComponentBackground(getBackground());
        }
    }

    /**
     * Sets the component background.
     *
     * @param colour the colour to set the component background to
     */
    private void setComponentBackground(Color colour) {
        m_component.setBackground(colour);

        if (!m_asLabel) {
            // Also need to update the combo-box "editor" background
            ((JComboBox) m_component).getEditor().getEditorComponent().setBackground(colour);

            // And the background of the disabled component
            m_disabledComponent.setBackground(colour);
        }
    }

    /**
     * Gets whether the "no colour" functionality is enabled.
     *
     * @return whether the "no colour" functionality is enabled
     */
    public boolean getNoColourEnabled() {
        return m_colourPanel.getNoColourEnabled();
    }

    /**
     * Sets whether the "no colour" functionality is enabled.
     *
     * @param noColourEnabled whether the "no colour" functionality is enabled
     */
    public void setNoColourEnabled(boolean noColourEnabled) {
        m_colourPanel.setNoColourEnabled(noColourEnabled);
    }

    /**
     * Gets the "no colour" label.
     *
     * @return the "no colour" label
     */
    public String getNoColourLabel() {
        return m_colourPanel.getNoColourLabel();
    }

    /**
     * Sets the "no colour" label.
     *
     * @param noColourLabel the "no colour" label
     */
    public void setNoColourLabel(String noColourLabel) {
        m_colourPanel.setNoColourLabel(noColourLabel);
    }

    /**
     * Gets the "more colours" label.
     *
     * @return the "more colours" label
     */
    public String getMoreColoursLabel() {
        return m_colourPanel.getMoreColoursLabel();
    }

    /**
     * Sets the "more colours" label.
     *
     * @param moreColoursLabel the "more colours" label
     */
    public void setMoreColoursLabel(String moreColoursLabel) {
        m_colourPanel.setMoreColoursLabel(moreColoursLabel);
    }

    /**
     * Gets whether the colour string (popup) is in hex.
     *
     * @return whether the colour string (popup) is in hex
     */
    public boolean getHexColourString() {
        return m_hexColourString;
    }

    /**
     * Sets whether the colour string (popup) is in hex.
     *
     * @param hexColourString whether the colour string (popup) is in hex
     */
    public void setHexColourString(boolean hexColourString) {
        m_hexColourString = hexColourString;
    }

    /**
     * Add an action listener to the font selector.
     * Called when the colour is changed.
     *
     * @param al the action listener to add
     */
    public void addActionListener(ActionListener al) {
        m_listenerList.add(al);
    }

    /**
     * Remove an action listener from the font selector.
     * Called when the colour is changed.
     *
     * @param al the action listener to remove
     */
    public void removeActionListener(ActionListener al) {
        m_listenerList.remove(al);
    }

    /**
     * Add a cancel action listener to the font selector.
     * Called when the colour change is cancelled or the
     * colour is the same as it was.
     *
     * @param al the cancel action listener to add
     */
    public void addCancelActionListener(ActionListener al) {
        m_cancelListenerList.add(al);
    }

    /**
     * Remove a cancel action listener from the font selector.
     * Called when the colour change is cancelled or the
     * colour is the same as it was.
     *
     * @param al the action listener to remove
     */
    public void removeCancelActionListener(ActionListener al) {
        m_cancelListenerList.remove(al);
    }

    /**
     * Updates the list of listeners.
     * @param colourSet whether the colour was actually set
     */
    private void updateListeners(boolean colourSet) {
        ActionEvent e = new ActionEvent(this, 0, null);

        // Call the appropriate listeners
        if (colourSet) {
            for (Iterator iter = m_listenerList.iterator(); iter.hasNext(); ) {
                ((ActionListener) iter.next()).actionPerformed(e);
            }
        }
        else {
            for (Iterator iter = m_cancelListenerList.iterator(); iter.hasNext(); ) {
                ((ActionListener) iter.next()).actionPerformed(e);
            }
        }
    }

    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        
        // Set enabled on the hidden panel
        m_hiddenPanel.setEnabled(enabled);

        if (m_asLabel) {
            // Set enabled on the component (the label)
            m_component.setEnabled(enabled);
        }
        else {
            // Note we don't set enabled on the combo-box because when
            // disabled it would then draw in gray :( Instead we have a
            // disabled component (a plain label) which won't have any
            // events attached or any combo box pull-down.
            remove(m_component);
            remove(m_disabledComponent);
            add(enabled ? m_component : m_disabledComponent, "0,0");
        }
    }

    /**
     * Raises the popup menu (if enabled).
     */
    public void raisePopup() {
        showPopup();
    }

    /**
     * Removes the component border.
     */
    public void removeComponentBorder() {
        m_component.setBorder(null);
        
        if (!m_asLabel) {
            m_disabledComponent.setBorder(null);
        }
    }

    /**
     * Toggle the popup menu.
     */
    private void togglePopup() {
        if ((m_window != null) && m_window.isVisible()) {
            hidePopup(true);
        }
        else {
            showPopup();
        }
    }

    /**
     * Show the popup menu.
     */
    private void showPopup() {
        if (isEnabled()) {
            // Set the colour
            m_colourPanel.setColour(m_colour, true);

            Point location = getLocationOnScreen();
            int rootX      = location.x;
            int rootY      = location.y;

            if (m_window == null) {
                // Create a new popup window
                m_window = new JWindow((Window) getRootPane().getParent());

                // Add our colour selector, size the window correctly and add focus listener
                m_window.getContentPane().add(m_colourPanel);
                m_window.setSize(m_window.getContentPane().getPreferredSize());
                m_window.addFocusListener(m_windowFocusListener);
                m_window.addKeyListener(m_windowKeyListener);
            }

            // Position the window, show it and grab the focus
            int screenWidth  = Toolkit.getDefaultToolkit().getScreenSize().width;
            int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
            int windowBottom = rootY + getHeight() + m_window.getHeight();
            int windowRight  = rootX + m_window.getWidth();

            // Adjust horizontally
            if (windowRight > screenWidth) {
                rootX -= windowRight - screenWidth;
            }

            // Do we show below or above?
            if (windowBottom > screenHeight) {
                m_window.setLocation(rootX, rootY - m_window.getHeight());
            }
            else {
                m_window.setLocation(rootX, rootY + getHeight());
            }

            // Show it, move it to the front and request focus
            m_window.show();
            m_window.toFront();
            m_window.requestFocus();
        }
    }

    /**
     * Hide the popup window.
     * @param callListeners whether to call the cancel action listeners
     */
    public void hidePopup(boolean callListeners) {
        if (m_window != null) {
            m_window.hide();
        }

        // Give the component back the focus
        m_component.requestFocus();
        
        if (callListeners) {
            updateListeners(false);
        }
    }
}
