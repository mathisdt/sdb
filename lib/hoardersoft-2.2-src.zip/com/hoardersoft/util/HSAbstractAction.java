package com.hoardersoft.util;

import javax.swing.*;

/**
 * Class used for actions.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 */
public abstract class HSAbstractAction extends AbstractAction {
    /**
     * Constructor.
     */
    public HSAbstractAction() {
        super();
    }

    /**
     * Constructor that takes a name.
     *
     * @param name the name
     */
    public HSAbstractAction(String name) {
        super(name);
    }

    /**
     * Class constructor that takes a name and help text.
     *
     * @param name the name of the action
     * @param helpText the help text for the action (null for none)
     */
    public HSAbstractAction(String name, String helpText) {
        super(name);

        if (helpText != null) {
            putValue(Action.LONG_DESCRIPTION, helpText);
        }
    }

    /**
     * Class constructor that takes a name, help text and an icon file.
     *
     * @param name the name of the action
     * @param helpText the help text for the action (null for none)
     * @param iconFile the icon file for the action
     */
    public HSAbstractAction(String name, String helpText, String iconFile) {
        this(name, helpText, HSIconUtil.loadImage(iconFile), null);
    }

    /**
     * Class constructor that takes a name, help text and an icon file.
     *
     * @param name the name of the action
     * @param helpText the help text for the action (null for none)
     * @param icon the icon for the action
     */
    public HSAbstractAction(String name, String helpText, ImageIcon icon) {
        this(name, helpText, icon, null);
    }

    /**
     * Class constructor that takes a name, help text and an icon file.
     *
     * @param name the name of the action
     * @param helpText the help text for the action (null for none)
     * @param iconFile the icon file for the action
     * @param tooltipText the tooltip text for the action (null for none)
     */
    public HSAbstractAction(String name, String helpText, String iconFile, String tooltipText) {
        this(name, helpText, HSIconUtil.loadImage(iconFile), tooltipText);
    }

    /**
     * Class constructor that takes a name, help text and an icon file.
     *
     * @param name the name of the action
     * @param helpText the help text for the action (null for none)
     * @param icon the icon for the action
     * @param tooltipText the tooltip text for the action (null for none)
     */
    public HSAbstractAction(String name, String helpText, ImageIcon icon, String tooltipText) {
        super(name, icon);

        if (helpText != null) {
            putValue(Action.LONG_DESCRIPTION, helpText);
        }

        if (tooltipText != null) {
            putValue(Action.SHORT_DESCRIPTION, tooltipText);
        }
    }
}
