package com.hoardersoft.directorylister;

import com.hoardersoft.util.HSVersionUtil;

import java.io.File;
import java.io.FileFilter;
import java.util.Comparator;
import java.util.Arrays;

/**
 * Class used to display a recursive directory listing.
 *
 * Copyright (c) 2002 Richard Kent (richardk@macs.hw.ac.uk)
 *
 * The license for this software is contained in COPYING
 *
 * @author Richard Kent
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
public class HSDirectoryLister {
    private static final String USAGE        = "Usage: java HSDirectoryLister <directory> [<show size>] [<title>]\n\nVersion: " + HSVersionUtil.VERSION;
    private static final long MEGABYTE100    = 1024L * 1024L / 100L;
    private static HSFileFilter m_fileFilter = new HSFileFilter();
    private static HSDirFilter m_dirFilter   = new HSDirFilter();

    /**
     * Main command line program.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if ((args.length < 1) || args[0].equals("/?")) {
            System.out.println(USAGE);
            System.exit(0);
        }

        String directory = args[0];
        File root        = new File(directory);

        if (!root.exists() || !root.isDirectory()) {
            System.out.println("Error: <directory> must exist and must be a directory");
            System.out.println(USAGE);
            System.exit(0);
        }

        // Let's be flexible and allow parameters in any order
        String arg1           = (args.length > 1) ? args[1] : null;
        String arg2           = (args.length > 2) ? args[2] : null;
        boolean trueFalse1    = (arg1 != null) && isTrueFalse(arg1);
        boolean trueFalse2    = (arg2 != null) && isTrueFalse(arg2);
        boolean nonTrueFalse1 = (arg1 != null) && !isTrueFalse(arg1);
        boolean nonTrueFalse2 = (arg2 != null) && !isTrueFalse(arg2);
        boolean showSize      = trueFalse1 ? getTrueFalse(arg1) : (trueFalse2 ? getTrueFalse(arg2) : false);
        String title          = nonTrueFalse1 ? arg1 : (nonTrueFalse2 ? arg2 : args[0]);

        System.out.println(title);

        for (int i = 0; i < title.length(); i++) {
            System.out.print("-");
        }

        System.out.println();
        System.out.println();

        long size = listDirectory("", root, showSize);

        if (showSize) {
            System.out.println();
            System.out.println("Total (" + size + " bytes) (" + getMegString(size) + " meg)");
        }
    }

    /**
     * Returns whether a string matches "true" or "false".
     * @param string the string
     * @return whether the string matches "true" or "false"
     */
    private static boolean isTrueFalse(String string) {
        return (string != null) && (string.equalsIgnoreCase("true") || string.equalsIgnoreCase("false"));
    }

    /**
     * Gets a native boolean value from a string.
     * @param string the string
     * @return the native boolean value
     */
    private static boolean getTrueFalse(String string) {
        return Boolean.valueOf(string).booleanValue();
    }

    /**
     * Lists a directory.
     * @param prefix the prefix (used for indentation)
     * @param dir the directory to list
     * @param showSize whether to show the size
     * @return the size of the directory
     */
    private static long listDirectory(String prefix, File dir, boolean showSize) {
        File[] files          = dir.listFiles(m_fileFilter);
        File[] dirs           = dir.listFiles(m_dirFilter);
        HSFileComparator comp = new HSFileComparator();
        long size             = 0;

        Arrays.sort(files, comp);
        Arrays.sort(dirs, comp);

        // List directories first
        for (int i = 0; i < dirs.length; i++) {
            System.out.println(prefix + "+ " + dirs[i].getName());

            size += listDirectory("    " + prefix, dirs[i], showSize);
        }

        // Then list files
        for (int i = 0; i < files.length; i++) {
            long length = files[i].length();

            size += length;

            if (showSize) {
                System.out.println(prefix + files[i].getName() + " (" + length + " bytes) (" + getMegString(length) + " meg)");
            }
            else {
                System.out.println(prefix + files[i].getName());
            }
        }

        return size;
    }

    /**
     * Gets a megabyte string from a long byte count.
     * @param bytes the long number of bytes
     * @return the megabyte string
     */
    private static String getMegString(long bytes) {
        long meg100 = bytes / MEGABYTE100;

        return (meg100 / 100L) + "." + (meg100 % 100);
    }

    private static class HSFileFilter implements FileFilter {
        public boolean accept(File file) {
            return file.isFile();
        }
    }

    private static class HSDirFilter implements FileFilter {
        public boolean accept(File file) {
            return file.isDirectory();
        }
    }

    private static class HSFileComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            File f1 = (File) o1;
            File f2 = (File) o2;

            return f1.getName().compareToIgnoreCase(f2.getName());
        }
    }
}
