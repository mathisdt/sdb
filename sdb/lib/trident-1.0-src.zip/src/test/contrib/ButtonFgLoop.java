package test.contrib;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.pushingpixels.trident.Timeline;
import org.pushingpixels.trident.Timeline.RepeatBehavior;

public class ButtonFgLoop extends JFrame
{
    // enter the button with the mouse
    // exit it whenever
    // wait for the cycle to end
    // reenter the button

    public ButtonFgLoop ()
    {
        JButton button = createButton ("button");

        this.setLayout (new FlowLayout ());
        this.add (button);

        final Timeline timeline = createTimeline (button);

        button.addMouseListener (new MouseAdapter()
        {
            @Override
            public void mouseEntered (MouseEvent e)
            {
                timeline.playLoop (RepeatBehavior.REVERSE);
            }

            @Override
            public void mouseExited (MouseEvent e)
            {
                timeline.cancelAtCycleBreak();
            }
        });

        this.setSize (400, 200);
        this.setLocationRelativeTo (null);
        this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
    }

    private JButton createButton (String label)
    {
        JButton button = new JButton (label);
        button.setForeground (Color.blue);
        return button;
    }

    private Timeline createTimeline (JButton button)
    {
        Timeline timeline = new Timeline (button);
        timeline.setDuration (1500);
        timeline.addPropertyToInterpolate ("foreground", button.getForeground (), Color.red);
        return timeline;
    }

    public static void main (String[] args)
    {
        SwingUtilities.invokeLater (new Runnable ()
        {
            @Override
            public void run ()
            {
                new ButtonFgLoop ().setVisible (true);
            }
        });
    }
}
