package test;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.*;

public class Tracing extends JFrame {
	public Tracing() {
		final JPanel mainPanel = new JPanel() {
			long lastPainted = -1;

			@Override
			protected void paintComponent(Graphics g) {
				long curr = System.currentTimeMillis();
				long diff = (curr - lastPainted);
				if (lastPainted > 0) {
					System.out.println("Painting interval is " + diff);
				}
				lastPainted = curr;
				super.paintComponent(g);
				g.setColor(Color.black);
				g.drawString("" + lastPainted, 10, 20);
			}
		};

		this.add(mainPanel);
		this.setSize(300, 200);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		new Thread() {
			long lastLoop = -1;

			@Override
			public void run() {
				while (true) {
					try {
						Thread.sleep(40);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					long curr = System.currentTimeMillis();
					long diff = (curr - lastLoop);
					if (lastLoop > 0) {
						System.out.println("Sleeping interval is " + diff);
					}
					lastLoop = curr;
					mainPanel.repaint();
				}
			}
		}.start();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new Tracing().setVisible(true);
			}
		});
	}

}
