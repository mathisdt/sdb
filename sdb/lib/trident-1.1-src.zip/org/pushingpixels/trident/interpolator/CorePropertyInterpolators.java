package org.pushingpixels.trident.interpolator;

import java.util.*;

public class CorePropertyInterpolators implements PropertyInterpolatorSource {
	private Set<PropertyInterpolator> interpolators;

	public CorePropertyInterpolators() {
		this.interpolators = new HashSet<PropertyInterpolator>();
		this.interpolators.add(new IntegerPropertyInterpolator());
		this.interpolators.add(new FloatPropertyInterpolator());
	}

	@Override
	public Set<PropertyInterpolator> getPropertyInterpolators() {
		return Collections.unmodifiableSet(this.interpolators);
	}

	private static class FloatPropertyInterpolator implements
			PropertyInterpolator<Float> {
		@Override
		public Class getBasePropertyClass() {
			return Float.class;
		}

		@Override
		public Float interpolate(Float from, Float to, float timelinePosition) {
			return from + (to - from) * timelinePosition;
		}
	}

	private static class IntegerPropertyInterpolator implements
			PropertyInterpolator<Integer> {
		@Override
		public Class getBasePropertyClass() {
			return Integer.class;
		}

		@Override
		public Integer interpolate(Integer from, Integer to,
				float timelinePosition) {
			return (int) (from + (to - from) * timelinePosition);
		}
	}
}
