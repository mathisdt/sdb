package org.pushingpixels.trident;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import org.pushingpixels.trident.interpolator.KeyFrames;
import org.pushingpixels.trident.interpolator.PropertyInterpolator;

public class TimelinePropertyBuilder<T> {
	public static interface PropertySetter<T> {
		public void set(Object obj, String fieldName, T value);
	}

	private Object target; // may be null
	private final String propertyName; // required
	private T from; // optional
	private boolean isFromCurrent;
	private T to; // must be optional because of KeyFrames
	private PropertyInterpolator<T> interpolator; // optional
	private PropertySetter<T> setter; // optional
	private KeyFrames<T> keyFrames; // optional

	TimelinePropertyBuilder(String propertyName) {
		this.propertyName = propertyName;
		this.isFromCurrent = false;
	}

	public TimelinePropertyBuilder<T> from(T startValue) {
		if (this.from != null) {
			throw new IllegalArgumentException("from() can only be called once");
		}
		if (this.isFromCurrent) {
			throw new IllegalArgumentException(
					"from() cannot be called after fromCurrent()");
		}
		if (this.keyFrames != null) {
			throw new IllegalArgumentException(
					"from() cannot be called after goingThrough()");
		}
		this.from = startValue;
		return this;
	}

	public TimelinePropertyBuilder<T> fromCurrent() {
		if (this.isFromCurrent) {
			throw new IllegalArgumentException(
					"fromCurrent() can only be called once");
		}
		if (this.from != null) {
			throw new IllegalArgumentException(
					"fromCurrent() cannot be called after from()");
		}
		if (this.keyFrames != null) {
			throw new IllegalArgumentException(
					"fromCurrent() cannot be called after goingThrough()");
		}
		this.isFromCurrent = true;
		return this;
	}

	public TimelinePropertyBuilder<T> to(T endValue) {
		if (this.to != null) {
			throw new IllegalArgumentException("to() can only be called once");
		}
		if (this.keyFrames != null) {
			throw new IllegalArgumentException(
					"to() cannot be called after goingThrough()");
		}
		this.to = endValue;
		return this;
	}

	public TimelinePropertyBuilder<T> on(Object object) {
		this.target = object;
		return this;
	}

	public TimelinePropertyBuilder<T> interpolatedWith(
			PropertyInterpolator<T> pInterpolator) {
		if (this.interpolator != null) {
			throw new IllegalArgumentException(
					"interpolateWith() can only be called once");
		}
		this.interpolator = pInterpolator;
		return this;
	}

	public TimelinePropertyBuilder<T> setWith(PropertySetter<T> pSetter) {
		if (this.setter != null) {
			throw new IllegalArgumentException(
					"setWith() can only be called once");
		}
		this.setter = pSetter;
		return this;
	}

	public TimelinePropertyBuilder<T> goingThrough(KeyFrames<T> keyFrames) {
		if (this.keyFrames != null) {
			throw new IllegalArgumentException(
					"goingThrough() can only be called once");
		}
		if (this.isFromCurrent) {
			throw new IllegalArgumentException(
					"goingThrough() cannot be called after fromCurrent()");
		}
		if (this.from != null) {
			throw new IllegalArgumentException(
					"goingThrough() cannot be called after from()");
		}
		if (this.to != null) {
			throw new IllegalArgumentException(
					"goingThrough() cannot be called after to()");
		}
		this.keyFrames = keyFrames;
		return this;
	}

	AbstractFieldInfo getFieldInfo(Timeline timeline) {
		if (this.target == null) {
			this.target = timeline.mainObject;
		}

		if (this.keyFrames != null) {
			return new KeyFramesFieldInfo(this.target, this.propertyName,
					this.keyFrames, this.setter);
		}

		if (this.isFromCurrent) {
			if (this.interpolator == null) {
				this.interpolator = TridentConfig.getInstance()
						.getPropertyInterpolator(this.to);

				if (this.interpolator == null) {
					throw new IllegalArgumentException(
							"No interpolator found for "
									+ this.to.getClass().getName());
				}
			}
			return new GenericFieldInfoTo(this.target, this.propertyName,
					this.to, this.interpolator, this.setter);
		}

		if (this.interpolator == null) {
			this.interpolator = TridentConfig.getInstance().getPropertyInterpolator(
					this.from, this.to);

			if (this.interpolator == null) {
				throw new IllegalArgumentException("No interpolator found for "
						+ this.from.getClass().getName() + ":"
						+ this.to.getClass().getName());
			}
		}
		return new GenericFieldInfo(this.target, this.propertyName, this.from,
				this.to, this.interpolator, this.setter);
	}

	abstract class AbstractFieldInfo<T> {
		protected Object object;

		protected String fieldName;

		protected PropertySetter setter;

		protected T from;

		protected T to;

		public AbstractFieldInfo(Object obj, String fieldName,
				PropertySetter<T> pSetter) {
			this.object = obj;
			this.fieldName = fieldName;
			if (pSetter != null) {
				this.setter = pSetter;
			} else {
				try {
					PropertyDescriptor desc = new PropertyDescriptor(fieldName,
							obj.getClass(), null, "set"
									+ Character
											.toUpperCase(fieldName.charAt(0))
									+ fieldName.substring(1));
					final Method setterMethod = desc.getWriteMethod();
					this.setter = new PropertySetter<T>() {
						@Override
						public void set(Object obj, String fieldName, T value) {
							try {
								setterMethod.invoke(obj, value);
							} catch (Throwable t) {
								throw new RuntimeException(t);
							}
						}
					};
				} catch (Throwable exc) {
					exc.printStackTrace();
				}
			}
		}

		protected void setValues(T from, T to) {
			this.from = from;
			this.to = to;
		}

		public abstract void onStart();

		public abstract void updateFieldValue(float timelinePosition);
	}

	private class GenericFieldInfoTo extends AbstractFieldInfo<Object> {
		private PropertyInterpolator propertyInterpolator;

		private Object to;

		public GenericFieldInfoTo(Object obj, String fieldName, Object to,
				PropertyInterpolator propertyInterpolator,
				PropertySetter propertySetter) {
			super(obj, fieldName, propertySetter);
			this.propertyInterpolator = propertyInterpolator;
			this.to = to;
		}

		@Override
		public void onStart() {
			try {
				PropertyDescriptor desc = new PropertyDescriptor(fieldName,
						this.object.getClass(), "get"
								+ Character.toUpperCase(fieldName.charAt(0))
								+ fieldName.substring(1), null);
				Method getter = desc.getReadMethod();
				this.from = getter.invoke(this.object);
			} catch (Throwable exc) {
				exc.printStackTrace();
			}
		}

		@Override
		public void updateFieldValue(float timelinePosition) {
			if (this.setter != null) {
				try {
					Object value = this.propertyInterpolator.interpolate(from,
							to, timelinePosition);
					this.setter.set(this.object, this.fieldName, value);
				} catch (Throwable exc) {
					System.err.println("Exception occurred in updating field '"
							+ this.fieldName + "' of object "
							+ this.object.getClass().getCanonicalName()
							+ " at timeline position " + timelinePosition);
					exc.printStackTrace();
				}
			}
		}
	}

	private class GenericFieldInfo extends AbstractFieldInfo<Object> {
		private PropertyInterpolator propertyInterpolator;

		public GenericFieldInfo(Object obj, String fieldName, Object from,
				Object to, PropertyInterpolator propertyInterpolator,
				PropertySetter propertySetter) {
			super(obj, fieldName, propertySetter);
			this.propertyInterpolator = propertyInterpolator;
			this.setValues(from, to);
		}

		@Override
		public void onStart() {
		}

		@Override
		public void updateFieldValue(float timelinePosition) {
			if (this.setter != null) {
				try {
					Object value = this.propertyInterpolator.interpolate(from,
							to, timelinePosition);
					this.setter.set(this.object, this.fieldName, value);
				} catch (Throwable exc) {
					System.err.println("Exception occurred in updating field '"
							+ this.fieldName + "' of object "
							+ this.object.getClass().getCanonicalName()
							+ " at timeline position " + timelinePosition);
					exc.printStackTrace();
				}
			}
		}
	}

	private class KeyFramesFieldInfo extends AbstractFieldInfo<Object> {
		KeyFrames keyFrames;

		public KeyFramesFieldInfo(Object obj, String fieldName,
				KeyFrames keyFrames, PropertySetter propertySetter) {
			super(obj, fieldName, propertySetter);
			this.keyFrames = keyFrames;
		}

		@Override
		public void onStart() {
		}

		@Override
		public void updateFieldValue(float timelinePosition) {
			if (this.setter != null) {
				try {
					Object value = this.keyFrames.getValue(timelinePosition);
					this.setter.set(this.object, this.fieldName, value);
				} catch (Throwable exc) {
					exc.printStackTrace();
				}
			}
		}
	}

}
