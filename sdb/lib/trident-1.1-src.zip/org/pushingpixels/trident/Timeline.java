/*
 * Copyright (c) 2005-2009 Trident Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of Trident Kirill Grouchnikov nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.pushingpixels.trident;

import java.util.*;

import org.pushingpixels.trident.TimelineEngine.FullObjectID;
import org.pushingpixels.trident.TimelineEngine.TimelineOperationKind;
import org.pushingpixels.trident.TimelinePropertyBuilder.AbstractFieldInfo;
import org.pushingpixels.trident.callback.*;
import org.pushingpixels.trident.ease.Linear;
import org.pushingpixels.trident.ease.TimelineEase;
import org.pushingpixels.trident.interpolator.KeyFrames;
import org.pushingpixels.trident.interpolator.PropertyInterpolator;

public class Timeline implements TimelineScenario.TimelineScenarioActor {
	Object mainObject;

	Comparable<?> secondaryId;

	FullObjectID fullObjectID;

	long duration;

	long initialDelay;

	long cycleDelay;

	boolean isLooping;

	int repeatCount;

	RepeatBehavior repeatBehavior;

	UIToolkitHandler uiToolkitHandler;

	Chain callback;

	List<AbstractFieldInfo> propertiesToInterpolate;

	/**
	 * Is used to create unique value for the {@link #id} field.
	 */
	static long counter;

	/**
	 * Unique ID.
	 */
	protected long id;

	/**
	 * Timeline position.
	 */
	float durationFraction;

	/**
	 * Timeline position.
	 */
	float timelinePosition;

	long timeUntilPlay;

	/**
	 * Indication how many loop cycles are left. Relevant only when
	 * {@link #isLooping} is <code>true</code>. Value -1 indicates endless loop.
	 */
	// int loopsToLive;

	/**
	 * Indication whether the looping timeline should stop at reaching the end
	 * of the cycle. Relevant only when {@link #isLooping} is <code>true</code>.
	 */
	boolean toCancelAtCycleBreak;

	Stack<TimelineState> stateStack;

	TimelineEase ease;

	private int doneCount;

	public enum RepeatBehavior {
		LOOP, REVERSE
	}

	public enum TimelineState {
		IDLE(false), READY(false), PLAYING_FORWARD(true), PLAYING_REVERSE(true), SUSPENDED(
				false), CANCELLED(false), DONE(false);

		private boolean isActive;

		private TimelineState(boolean isActive) {
			this.isActive = isActive;
		}
	}

	// protected abstract class AbstractFieldInfo<T> {
	// protected Object object;
	//
	// protected String fieldName;
	//
	// protected Method setter;
	//
	// protected T from;
	//
	// protected T to;
	//
	// public AbstractFieldInfo(Object obj, String fieldName, Class fieldClass)
	// {
	// this.object = obj;
	// this.fieldName = fieldName;
	// try {
	// PropertyDescriptor desc = new PropertyDescriptor(fieldName, obj
	// .getClass(), null, "set"
	// + Character.toUpperCase(fieldName.charAt(0))
	// + fieldName.substring(1));
	// this.setter = desc.getWriteMethod();
	// } catch (Throwable exc) {
	// exc.printStackTrace();
	// }
	// }
	//
	// protected void setValues(T from, T to) {
	// this.from = from;
	// this.to = to;
	// }
	//
	// public abstract void onStart();
	//
	// public abstract void updateFieldValue(float timelinePosition);
	// }
	//
	// private class GenericFieldInfoTo extends AbstractFieldInfo<Object> {
	// private PropertyInterpolator propertyInterpolator;
	//
	// private Object to;
	//
	// public GenericFieldInfoTo(Object obj, String fieldName, Object to,
	// PropertyInterpolator propertyInterpolator) {
	// super(obj, fieldName, propertyInterpolator.getBasePropertyClass());
	// this.propertyInterpolator = propertyInterpolator;
	// this.to = to;
	// }
	//
	// @Override
	// public void onStart() {
	// try {
	// PropertyDescriptor desc = new PropertyDescriptor(fieldName,
	// this.object.getClass(), "get"
	// + Character.toUpperCase(fieldName.charAt(0))
	// + fieldName.substring(1), null);
	// Method getter = desc.getReadMethod();
	// this.from = getter.invoke(this.object);
	// } catch (Throwable exc) {
	// exc.printStackTrace();
	// }
	// }
	//
	// @Override
	// public void updateFieldValue(float timelinePosition) {
	// if (this.setter != null) {
	// try {
	// Object value = this.propertyInterpolator.interpolate(from,
	// to, timelinePosition);
	// this.setter.invoke(this.object, value);
	// } catch (Throwable exc) {
	// System.err.println("Exception occurred in updating field '"
	// + this.fieldName + "' of object "
	// + this.object.getClass().getCanonicalName()
	// + " at timeline position " + timelinePosition);
	// exc.printStackTrace();
	// }
	// }
	// }
	// }
	//
	// private class GenericFieldInfo extends AbstractFieldInfo<Object> {
	// private PropertyInterpolator propertyInterpolator;
	//
	// public GenericFieldInfo(Object obj, String fieldName, Object from,
	// Object to, PropertyInterpolator propertyInterpolator) {
	// super(obj, fieldName, propertyInterpolator.getBasePropertyClass());
	// this.propertyInterpolator = propertyInterpolator;
	// this.setValues(from, to);
	// }
	//
	// @Override
	// public void onStart() {
	// }
	//
	// @Override
	// public void updateFieldValue(float timelinePosition) {
	// if (this.setter != null) {
	// try {
	// Object value = this.propertyInterpolator.interpolate(from,
	// to, timelinePosition);
	// this.setter.invoke(this.object, value);
	// } catch (Throwable exc) {
	// System.err.println("Exception occurred in updating field '"
	// + this.fieldName + "' of object "
	// + this.object.getClass().getCanonicalName()
	// + " at timeline position " + timelinePosition);
	// exc.printStackTrace();
	// }
	// }
	// }
	// }
	//
	// private class KeyFramesFieldInfo extends AbstractFieldInfo<Object> {
	// KeyFrames keyFrames;
	//
	// public KeyFramesFieldInfo(Object obj, String fieldName,
	// KeyFrames keyFrames) {
	// super(obj, fieldName, keyFrames.getType());
	// this.keyFrames = keyFrames;
	// }
	//
	// @Override
	// public void onStart() {
	// }
	//
	// @Override
	// public void updateFieldValue(float timelinePosition) {
	// if (this.setter != null) {
	// try {
	// Object value = this.keyFrames.getValue(timelinePosition);
	// this.setter.invoke(this.object, value);
	// } catch (Throwable exc) {
	// exc.printStackTrace();
	// }
	// }
	// }
	// }

	private class Setter extends TimelineCallbackAdapter {
		@Override
		public void onTimelineStateChanged(TimelineState oldState,
				TimelineState newState, float durationFraction,
				float timelinePosition) {
			if (newState == TimelineState.READY) {
				for (AbstractFieldInfo fInfo : propertiesToInterpolate) {
					// check whether the object is in the ready state
					if ((uiToolkitHandler != null)
							&& !uiToolkitHandler.isInReadyState(fInfo.object))
						continue;
					fInfo.onStart();
				}
			}

			// Fix for issue 5 - update field values only when
			// either old or new state (or both) are active. Otherwise
			// it's a transition between inactive states (such as from
			// DONE to IDLE) that shouldn't trigger the property changes
			if (oldState.isActive || newState.isActive) {
				for (AbstractFieldInfo fInfo : propertiesToInterpolate) {
					// check whether the object is in the ready state
					if ((uiToolkitHandler != null)
							&& !uiToolkitHandler.isInReadyState(fInfo.object))
						continue;
					fInfo.updateFieldValue(timelinePosition);
				}
			}
		}

		@Override
		public void onTimelinePulse(float durationFraction,
				float timelinePosition) {
			for (AbstractFieldInfo fInfo : propertiesToInterpolate) {
				// check whether the object is in the ready state
				if ((uiToolkitHandler != null)
						&& !uiToolkitHandler.isInReadyState(fInfo.object))
					continue;
				// System.err.println("Timeline @" + Timeline.this.hashCode()
				// + " at position " + timelinePosition);
				fInfo.updateFieldValue(timelinePosition);
			}
		}
	}

	@RunOnUIThread
	private class UISetter extends Setter {
	}

	class Chain implements TimelineCallback {
		private List<TimelineCallback> callbacks;

		public Chain(TimelineCallback... callbacks) {
			this.callbacks = new ArrayList<TimelineCallback>();
			for (TimelineCallback callback : callbacks)
				this.callbacks.add(callback);
		}

		public void addCallback(TimelineCallback callback) {
			this.callbacks.add(callback);
		}

		@Override
		public void onTimelineStateChanged(final TimelineState oldState,
				final TimelineState newState, final float durationFraction,
				final float timelinePosition) {
			if ((uiToolkitHandler != null)
					&& !uiToolkitHandler.isInReadyState(mainObject))
				return;
			for (final TimelineCallback callback : this.callbacks) {
				// special handling for chained callbacks not running on UI
				// thread
				boolean shouldRunOnUIThread = false;
				Class<?> clazz = callback.getClass();
				while ((clazz != null) && !shouldRunOnUIThread) {
					shouldRunOnUIThread = clazz
							.isAnnotationPresent(RunOnUIThread.class);
					clazz = clazz.getSuperclass();
				}
				if (shouldRunOnUIThread
						&& (Timeline.this.uiToolkitHandler != null)) {
					Timeline.this.uiToolkitHandler
							.runOnUIThread(new Runnable() {
								public void run() {
									callback.onTimelineStateChanged(oldState,
											newState, durationFraction,
											timelinePosition);
								}
							});
				} else {
					callback.onTimelineStateChanged(oldState, newState,
							durationFraction, timelinePosition);
				}
			}
		}

		@Override
		public void onTimelinePulse(final float durationFraction,
				final float timelinePosition) {
			if ((uiToolkitHandler != null)
					&& !uiToolkitHandler.isInReadyState(mainObject))
				return;
			for (final TimelineCallback callback : this.callbacks) {
				// special handling for chained callbacks not running on UI
				// thread
				boolean shouldRunOnUIThread = false;
				Class<?> clazz = callback.getClass();
				while ((clazz != null) && !shouldRunOnUIThread) {
					shouldRunOnUIThread = clazz
							.isAnnotationPresent(RunOnUIThread.class);
					clazz = clazz.getSuperclass();
				}
				if (shouldRunOnUIThread
						&& (Timeline.this.uiToolkitHandler != null)) {
					Timeline.this.uiToolkitHandler
							.runOnUIThread(new Runnable() {
								public void run() {
									if (Timeline.this.getState() == TimelineState.CANCELLED)
										return;
									// System.err.println("Timeline @"
									// + Timeline.this.hashCode());
									callback.onTimelinePulse(durationFraction,
											timelinePosition);
								}
							});
				} else {
					// System.err.println("Timeline @" +
					// Timeline.this.hashCode());
					callback
							.onTimelinePulse(durationFraction, timelinePosition);
				}
			}
		}
	}

	public Timeline() {
		this(null);
	}

	public Timeline(Object mainTimelineObject) {
		this.mainObject = mainTimelineObject;

		for (UIToolkitHandler uiToolkitHandler : TridentConfig.getInstance()
				.getUIToolkitHandlers()) {
			if (uiToolkitHandler.isHandlerFor(mainTimelineObject)) {
				this.uiToolkitHandler = uiToolkitHandler;
				break;
			}
		}

		// if the main timeline object is handled by a UI toolkit handler,
		// the setters registered with the different addProperty
		// APIs need to run with the matching threading policy
		TimelineCallback setterCallback = (this.uiToolkitHandler != null) ? new UISetter()
				: new Setter();
		this.callback = new Chain(setterCallback);

		this.duration = 500;
		this.propertiesToInterpolate = new ArrayList<AbstractFieldInfo>();
		this.id = Timeline.getId();
		// this.loopsToLive = -1;

		this.stateStack = new Stack<TimelineState>();
		this.stateStack.push(TimelineState.IDLE);
		this.doneCount = 0;

		this.ease = new Linear();
	}

	public final void setSecondaryID(Comparable<?> secondaryId) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.secondaryId = secondaryId;
	}

	public final void setDuration(long durationMs) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.duration = durationMs;
	}

	public final void setInitialDelay(long initialDelay) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.initialDelay = initialDelay;
	}

	public final void setCycleDelay(long cycleDelay) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.cycleDelay = cycleDelay;
	}

	public final void addCallback(TimelineCallback callback) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.callback.addCallback(callback);
	}

	public static <T> TimelinePropertyBuilder<T> property(String propertyName) {
		return new TimelinePropertyBuilder<T>(propertyName);
	}

	public final <T> void addPropertyToInterpolate(
			TimelinePropertyBuilder<T> propertyBuilder) {
		this.propertiesToInterpolate.add(propertyBuilder.getFieldInfo(this));
	}

	public final <T> void addPropertyToInterpolate(String propName,
			KeyFrames<T> keyFrames) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.goingThrough(keyFrames));
		// this.propertiesToInterpolate.add(new KeyFramesFieldInfo(
		// this.mainObject, propName, keyFrames));
	}

	public final <T> void addPropertyToInterpolate(String propName, T from, T to) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.from(from).to(to));
		// this.addPropertyToInterpolate(this.mainObject, propName, from, to);
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolate(Object object,
			String propName, T from, T to) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.on(object).from(from).to(to));
		// PropertyInterpolator matchingInterpolator =
		// TridentConfig.getInstance()
		// .getInterpolator(from, to);
		//
		// if (matchingInterpolator == null) {
		// throw new IllegalArgumentException("No interpolator found for "
		// + from.getClass().getName() + ":" + to.getClass().getName());
		// }
		//
		// this.addPropertyToInterpolate(object, propName, from, to,
		// matchingInterpolator);
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolate(String propName, T from,
			T to, PropertyInterpolator<T> propertyInterpolator) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.from(from).to(to).interpolatedWith(propertyInterpolator));
		// this.propertiesToInterpolate.add(new
		// GenericFieldInfo(this.mainObject,
		// propName, from, to, propertyInterpolator));
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolate(Object obj, String propName,
			T from, T to, PropertyInterpolator<T> propertyInterpolator) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName).on(obj)
				.from(from).to(to).interpolatedWith(propertyInterpolator));
		// if (this.getState() != TimelineState.IDLE) {
		// throw new IllegalArgumentException(
		// "Cannot change state of non-idle timeline");
		// }
		// this.propertiesToInterpolate.add(new GenericFieldInfo(obj, propName,
		// from, to, propertyInterpolator));
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolateTo(String propName, T to) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.fromCurrent().to(to));
		// PropertyInterpolator matchingInterpolator =
		// TridentConfig.getInstance()
		// .getInterpolator(to);
		//
		// if (matchingInterpolator == null) {
		// throw new IllegalArgumentException("No interpolator found for "
		// + to.getClass().getName());
		// }
		//
		// this.addPropertyToInterpolateTo(propName, to, matchingInterpolator);
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolateTo(String propName, T to,
			PropertyInterpolator<T> propertyInterpolator) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.fromCurrent().to(to).interpolatedWith(propertyInterpolator));
		// this.addPropertyToInterpolateTo(this.mainObject, propName, to,
		// propertyInterpolator);
	}

	/**
	 * Use {@link #addPropertyToInterpolate(TimelinePropertyBuilder)} instead.
	 */
	@Deprecated
	public final <T> void addPropertyToInterpolateTo(Object object,
			String propName, T to, PropertyInterpolator<T> propertyInterpolator) {
		this.addPropertyToInterpolate(Timeline.<T> property(propName)
				.on(object).fromCurrent().to(to).interpolatedWith(
						propertyInterpolator));
		// if (this.getState() != TimelineState.IDLE) {
		// throw new IllegalArgumentException(
		// "Cannot change state of non-idle timeline");
		// }
		// this.propertiesToInterpolate.add(new GenericFieldInfoTo(object,
		// propName, to, propertyInterpolator));
	}

	public void play() {
		this.playSkipping(0);
	}

	public void playSkipping(final long msToSkip) {
		if ((this.initialDelay + this.duration) < msToSkip) {
			throw new IllegalArgumentException(
					"Required skip longer than initial delay + duration");
		}
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.PLAY, new Runnable() {
					@Override
					public void run() {
						Timeline.this.isLooping = false;
						TimelineEngine.getInstance().play(Timeline.this, false,
								msToSkip);
					}
				});
	}

	public void playReverse() {
		playReverseSkipping(0);
	}

	public void playReverseSkipping(final long msToSkip) {
		if ((this.initialDelay + this.duration) < msToSkip) {
			throw new IllegalArgumentException(
					"Required skip longer than initial delay + duration");
		}
		// System.out.println("Enqueueing operation");
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.PLAY, new Runnable() {
					@Override
					public void run() {
						Timeline.this.isLooping = false;
						// System.out.println("Running queued operation");
						TimelineEngine.getInstance().playReverse(Timeline.this,
								false, msToSkip);
					}
				});
	}

	public void replay() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.PLAY, new Runnable() {
					@Override
					public void run() {
						Timeline.this.isLooping = false;
						TimelineEngine.getInstance().play(Timeline.this, true,
								0);
					}
				});
	}

	public void replayReverse() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.PLAY, new Runnable() {
					@Override
					public void run() {
						Timeline.this.isLooping = false;
						TimelineEngine.getInstance().playReverse(Timeline.this,
								true, 0);
					}
				});
	}

	public void playLoop(RepeatBehavior repeatBehavior) {
		this.playLoop(-1, repeatBehavior);
	}

	public void playLoopSkipping(RepeatBehavior repeatBehavior,
			final long msToSkip) {
		this.playLoopSkipping(-1, repeatBehavior, msToSkip);
	}

	public void playLoop(int loopCount, RepeatBehavior repeatBehavior) {
		this.playLoopSkipping(loopCount, repeatBehavior, 0);
	}

	public void playLoopSkipping(final int loopCount,
			final RepeatBehavior repeatBehavior, final long msToSkip) {
		if ((this.initialDelay + this.duration) < msToSkip) {
			throw new IllegalArgumentException(
					"Required skip longer than initial delay + duration");
		}
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.PLAY, new Runnable() {
					@Override
					public void run() {
						Timeline.this.isLooping = true;
						Timeline.this.repeatCount = loopCount;
						Timeline.this.repeatBehavior = repeatBehavior;
						TimelineEngine.getInstance().playLoop(Timeline.this,
								msToSkip);
					}
				});
	}

	public void cancel() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.CANCEL, null);
	}

	public void abort() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.ABORT, null);
	}

	public void suspend() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.SUSPEND, null);
	}

	public void resume() {
		TimelineEngine.getInstance().enqueueTimelineOperation(this,
				TimelineOperationKind.RESUME, null);
	}

	/**
	 * Requests that the specified timeline should stop at the end of the cycle.
	 * This method should be called only on looping timelines.
	 */
	public void cancelAtCycleBreak() {
		if (!this.isLooping)
			throw new IllegalArgumentException(
					"Can only be called on looping timelines");
		this.toCancelAtCycleBreak = true;
	}

	/**
	 * Returns a unique ID.
	 * 
	 * @return Unique ID.
	 */
	protected static synchronized long getId() {
		return counter++;
	}

	public final float getTimelinePosition() {
		return this.timelinePosition;
	}

	public final float getDurationFraction() {
		return this.durationFraction;
	}

	public final TimelineState getState() {
		return this.stateStack.peek();
	}

	public final void setEase(TimelineEase ease) {
		if (this.getState() != TimelineState.IDLE) {
			throw new IllegalArgumentException(
					"Cannot change state of non-idle timeline");
		}
		this.ease = ease;
	}

	@Override
	public boolean isDone() {
		return (this.doneCount > 0);
	}

	@Override
	public boolean supportsReplay() {
		return true;
	}

	@Override
	public void resetDoneFlag() {
		this.doneCount = 0;
	}

	@Override
	public String toString() {
		StringBuffer res = new StringBuffer();
		// if (this.timelineKind != null) {
		// res.append("[" + this.timelineKind.id + "] ");
		// }

		res.append(this.mainObject.toString());
		if (this.secondaryId != null) {
			res.append(":" + this.secondaryId.toString());
		}

		res.append(" " + this.getState().name());
		res.append(":" + this.timelinePosition);

		return res.toString();
	}

	void replaceState(TimelineState state) {
		this.stateStack.pop();
		this.pushState(state);
	}

	void pushState(TimelineState state) {
		if (state == TimelineState.DONE)
			this.doneCount++;
		this.stateStack.add(state);
	}

	void popState() {
		this.stateStack.pop();
	}

	public final long getDuration() {
		return this.duration;
	}
}